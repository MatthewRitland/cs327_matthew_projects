#include "pokemon_obj.h"
#include <vector>
#include <cmath>

Pokemon::Pokemon(int level) {
    this->level = level;
    

    int random_index = rand() % pokemon_db.size();
    base_species = &pokemon_db[random_index];

    // randomize gender and shiny
    gender = (rand() % 2 == 0) ? "Male" : "Female";
    is_shiny = (rand() % 8192 == 0);

    // randomize IV (from 0 to 16, 0000 to 1111)
    iv_hp = rand() % 16;
    iv_attack = rand() % 16;
    iv_defense = rand() % 16;
    iv_special_attack = rand() % 16;
    iv_special_defense = rand() % 16;   
    iv_speed = rand() % 16;


    // 4. Calculate actual stats & select moves
    get_base_stats();
    calculate_stats();
    select_moves();

    this->max_hp = this->hp;
}

void Pokemon::get_base_stats() {
    bool found = false;
    for (pokemon_stats &stat_entry : pokemon_stats_db) {
        if (stat_entry.pokemon_id == base_species->id) {
            found = true;
            // ID MATTERS!
            switch(stat_entry.stat_id) {
                case 1: base_hp = stat_entry.base_stat; break;// 1 = hp
                case 2: base_attack = stat_entry.base_stat; break; // 2 = attack
                case 3: base_defense = stat_entry.base_stat; break;
                case 4: base_special_attack = stat_entry.base_stat; break;
                case 5: base_special_defense = stat_entry.base_stat; break;
                case 6: base_speed = stat_entry.base_stat; break;
            }
            // 7 = accuracy, 8 = evasion, but these change mid-battle (1 for is_battle_only, so only mid fight)
        }
        else if (found) { 
            break;
        }
    }
}


void Pokemon::calculate_stats() {
    // HP = floor(((Base + IV) * 2 * Level) / 100) + Level + 10
    hp = std::floor(((base_hp + iv_hp) * 2 * level) / 100.0) + level + 10;

    // Otherstat = floor(((Base + IV) * 2 * Level) / 100) + 5
    attack          = std::floor(((base_attack + iv_attack) * 2 * level) / 100.0) + 5;
    defense         = std::floor(((base_defense + iv_defense) * 2 * level) / 100.0) + 5;
    special_attack  = std::floor(((base_special_attack + iv_special_attack) * 2 * level) / 100.0) + 5;
    special_defense = std::floor(((base_special_defense + iv_special_defense) * 2 * level) / 100.0) + 5;
    speed           = std::floor(((base_speed + iv_speed) * 2 * level) / 100.0) + 5;
}


// used to select up to 2 valid moves (valid meaning that it is unlocked by pokemon level)
void Pokemon::select_moves() {
    std::vector<int> valid_move_ids;
    bool moves_were_found = false;

    // finds all valid level up moves for this specific pokemon
    for (const pokemon_moves &pm : pokemon_moves_db) {


        if (pm.pokemon_id == base_species->species_id) {
            moves_were_found = true;
            // check if it's a valid level up move, compaing the required level (pm.level) against current pokemon level (this->level)
            if (pm.pokemon_move_method_id == 1 && pm.level <= this->level) {
                valid_move_ids.push_back(pm.move_id);
            }
        }
        // no need to keep reading down the file if all the possible moves were found (would be reading data with wrong pokemon_id)
        else if (moves_were_found) {
            break;
        }
    }

    move1 = nullptr;
    move2 = nullptr;

    // if no valid moves were found, just give it struggle
    if (valid_move_ids.empty()) {
        for (const moves &m : moves_db) {
            if (m.id == 165) { // struggle id from moves.csv: 165,struggle,1,1,50,1,,0,8,2,255,,1,1,5
                move1 = &m;
                break;
            }
        }
        return;
    }

    // assign selected moves 1 or 2 random, distinct moves from the valid moves vector
    int selected_move_id1 = valid_move_ids[rand() % valid_move_ids.size()];
    
    // in case there are no more moves, assign them the same for now in order to check later
    int selected_move_id2 = -1;
    if (valid_move_ids.size() > 1) {
        int count = 0;
        do {
            selected_move_id2 = valid_move_ids[rand() % valid_move_ids.size()];
            count++;
            
            // just chose 50 arbitrarily... this is in case there were many valid move ids.
            if (count > 50) {
                break;
            }
        } while (selected_move_id1 == selected_move_id2);
        
        // if they are still the same move, then just remove the second move. (kind of a janky fix)
        if (selected_move_id1 == selected_move_id2) {
            selected_move_id2 = -1;
        }
    }

    // determine how many we need to find (if still same, then can only have 1 move)
    int target_moves = (selected_move_id1 == -1) ? 1 : 2;
    int moves_found = 0;

    for (const moves &m : moves_db) {
        // if the move from moves matches the selected move id, then assign it
        if (m.id == selected_move_id1 && !move1) {
            move1 = &m;
            moves_found++;
        }
        else if (m.id == selected_move_id2 && !move2) {
            move2 = &m;
            moves_found++;
        }

        // break if there is only 1 move and it was found. (and 2, since can only do up to 2 moves)
        if (moves_found >= target_moves) {
            break; 
        }
    }
}