#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
//#include <endian.h>
//#include <sys/stat.h>
//#include <sys/types.h>
#include <limits.h>
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>

#include "heap.h"

#include <curses.h>

#include "db_parsing.h"
#include <cstdlib>
#include <vector>
#include "pokemon_obj.h"
#include <algorithm>


// declared in db_parsing.h, using keyword extern, but defined here
std::vector<pokemon> pokemon_db;
std::vector<moves> moves_db;
std::vector<pokemon_moves> pokemon_moves_db;
std::vector<pokemon_species> pokemon_species_db;
std::vector<experience> experience_db;
std::vector<type_names> type_names_db;
std::vector<pokemon_stats> pokemon_stats_db;
std::vector<stats> stats_db;
std::vector<pokemon_types> pokemon_types_db;



typedef struct path {
  heap_node_t *hn;
  uint8_t pos[2];
  uint8_t from[2];
  int32_t cost;
} path_t;

typedef enum dim {
  dim_x,
  dim_y,
  num_dims
} dim_t;

typedef uint8_t pair_t[num_dims];

// NO CHANGE constants
#define MAP_X              80
#define MAP_Y              21
#define MIN_TREES          10
#define MIN_BOULDERS       10
#define TREE_PROB          95
#define BOULDER_PROB       95

#define mappair(pair) (m->map[pair[dim_y]][pair[dim_x]])
#define mapxy(x, y) (m->map[y][x])
#define heightpair(pair) (m->height[pair[dim_y]][pair[dim_x]])
#define heightxy(x, y) (m->height[y][x])

typedef enum __attribute__ ((__packed__)) terrain_type {
  ter_debug,
  ter_boulder,
  ter_tree,
  ter_path,
  ter_mart,
  ter_center,
  ter_grass,
  ter_clearing,
  ter_mountain,
  ter_forest,
  ter_water
} terrain_type_t;

// enums for the different character types (compiler assigns 0 to last, num_character_types represents total types)
typedef enum {
  char_pc,
  char_hiker,
  char_rival,
  char_swimmer,
  char_pacer,
  char_wanderer,
  char_sentry,
  char_explorer,
  num_character_types,
} character_type_t;


 //cpp class
 class map_t {
public:
  terrain_type_t map[MAP_Y][MAP_X];
  uint8_t height[MAP_Y][MAP_X];
  uint8_t n, s, e, w;
  class character_t *npcs;
  int num_trainers;
};

class character_t {
public:
  character_type_t type;
  int x, y;
  int next_turn;
  int seq_num;
  int dir_x, dir_y;
  terrain_type_t spawn_terrain;
  int defeated; 
  std::vector<Pokemon> trained_pokemon;
  
  #define MAX_REVIVES 2
  #define MAX_POTIONS 3
  #define MAX_POKEBALLS 5
  int revives = MAX_REVIVES; 
  int potions = MAX_POTIONS;
  int pokeballs = MAX_POKEBALLS;
};

int calculate_damage(Pokemon* attacker, Pokemon* defender, const moves* move) {

  if (!move || move->power == 0) {
    return 1; 
  }

  // if rand() % 100 <= moves.accuracy then move hits
  if ((rand() % 100) > move->accuracy) {
    return 0; 
  }

  int atk = attacker->get_attack(); 
  int def = defender->get_defense();
  int level = attacker->get_level();

  
  // base damage 
  int damage = ((((2 * level / 5) + 2) * move->power * atk / def) / 50) + 2;

  // crits
  int threshold = attacker->base_speed / 2; // just use int division to floor
  float critical = ((rand() % 256) < threshold) ? 1.5f : 1.0f;

  // variance (b/w 0.85 and 1.0)
  float random_v = ((rand() % 16) + 85) / 100.0f;

  // STAB
  // Assuming you create a helper method to check if types match
  float stab = 1.0f;
  // loop through types, check if that move type matches pokemon type. If so, apply STAB
  for (const pokemon_types &pt : pokemon_types_db) {
    if (pt.pokemon_id == attacker->base_species->id) {
      if (pt.type_id == move->type_id) {
        stab = 1.5f;
        break;
      }
    }
  }

  float type_effectiveness = 1.0f; 

  // final damage calcuation
  damage = (int)(damage * critical * random_v * stab * type_effectiveness);

  // at least one dmg is done
  return std::max(1, damage);
}

// helper method for display_pokemon_encounter for switching pokemon
Pokemon* choose_trained_pokemon(character_t *pc, Pokemon *current_active, bool allow_cancel, const char* menu_title, bool is_revive = false) {
  while (true) {
    clear();
    mvprintw(2, 2, "%s", menu_title);
    
    // loop through all trained pokemon and display them
    for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
      mvprintw(4 + i, 2, "%d) %s (Lv %d) - HP: %d/%d", (int)(i + 1), 
        pc->trained_pokemon[i].get_species_identifier().c_str(), pc->trained_pokemon[i].get_level(), 
        pc->trained_pokemon[i].hp, pc->trained_pokemon[i].max_hp);
    }

    if (allow_cancel) {
      mvprintw(11, 2, "0) Cancel");
    }
    
    mvprintw(13, 2, "Choose a Pokemon:");
    refresh();

    int party_choice = getch();
    
    // Handle Cancel
    if (allow_cancel && party_choice == '0') {
      return NULL; 
    } 

    // Convert the ASCII character to the correct vector index
    int p_idx = party_choice - '1';

    if (p_idx >= 0 && p_idx < (int)pc->trained_pokemon.size()) {
      if (!is_revive && pc->trained_pokemon[p_idx].hp <= 0) {
        mvprintw(15, 2, "Selected Pokemon is fainted, try a different one.");
        getch();
      } 
      else if (is_revive && &pc->trained_pokemon[p_idx] == current_active) {
        mvprintw(15, 2, "%s is already active.", current_active->get_species_identifier().c_str());
        getch();
      } 
      else {
        return &pc->trained_pokemon[p_idx];
      }
    }
    else {
      mvprintw(15, 2, "Invalid choice.");
      getch();
    }
  }
}


// visually displays a pokemon encounter (doesn't do anything else yet!)
void display_pokemon_encounter(Pokemon *p, character_t *pc) {
  bool battle_is_active = true;
  int escape_attempts = 0;

  Pokemon *pc_active = NULL;
  for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
    if (pc->trained_pokemon[i].get_hp() > 0) {
      pc_active = &pc->trained_pokemon[i];
      break;
    }
  }

  if (!pc_active) {
    clear();
    mvprintw(0, 0, "You have no useable Pokemon!");
    refresh();
    getch();
    return; 
  }

  while (battle_is_active && p->get_hp() > 0) {
    clear();

    mvprintw(2, 2, "A wild %s appeared!", p->get_species_identifier().c_str());
    mvprintw(3, 2, "Level: %d", p->get_level());
    attron(COLOR_PAIR(7)); // make the hp red
    mvprintw(5, 2, "HP: %d", p->get_hp());
    attroff(COLOR_PAIR(7));
    mvprintw(6, 2, "ATK: %d    | DEF: %d", p->get_attack(), p->get_defense());
    mvprintw(7, 2, "SP.ATK: %d | SP.DEF: %d", p->get_special_attack(), p->get_special_defense());
    mvprintw(8, 2, "SPEED: %d", p->get_speed());
    
    // display the moves
    mvprintw(10, 2, "Wild %s's Moves:", p->get_species_identifier().c_str());
    mvprintw(11, 2, "- %s", p->get_move1_identifier().c_str());
    if (p->get_move2_identifier() != "") {
      mvprintw(12, 2, "- %s", p->get_move2_identifier().c_str());
    }

    // pc menu
    attron(COLOR_PAIR(1));
    mvprintw(14, 2, "Your %s (LVL %d) - HP: %d/%d", 
      pc_active->get_species_identifier().c_str(), pc_active->get_level(), 
      pc_active->get_hp(), pc_active->max_hp);
    mvprintw(15, 2, "ATK: %d    | DEF: %d", pc_active->get_attack(), pc_active->get_defense());
    mvprintw(16, 2, "SP.ATK: %d | SP.DEF: %d", pc_active->get_special_attack(), pc_active->get_special_defense());
    mvprintw(17, 2, "SPEED: %d", pc_active->get_speed());
    attroff(COLOR_PAIR(1));

    mvprintw(19, 2, "Your options are:");
    mvprintw(20, 4, "1) Fight    2) Bag");
    mvprintw(21, 4, "3) Pokemon  4) Run");
    refresh();

    // deal with user input
    int choice = getch();
    
    // FIGHT
    if (choice == '1') { 
      // move selection sub-menu
      clear();
      mvprintw(2, 2, "Choose %s's move to use:", pc_active->get_species_identifier().c_str());
      
      attron(COLOR_PAIR(1));
      mvprintw(4, 4, "1) %s", pc_active->get_move1_identifier().c_str());
      
      bool has_move2 = (pc_active->get_move2_identifier() != "");
      if (has_move2) {
        mvprintw(5, 4, "2) %s", pc_active->get_move2_identifier().c_str());
      }
      attroff(COLOR_PAIR(1));
      
      mvprintw(7, 4, "0) Cancel");
      refresh();

      int move_choice = getch();
      const moves* pc_move = NULL;

      if (move_choice == '1') {
        pc_move = pc_active->move1;
      }
      else if (move_choice == '2' && has_move2) {
        pc_move = pc_active->move2;
      }
      else {
        continue;
      }
      const moves* wild_move = (rand() % 2 == 0 && p->move2) ? p->move2 : p->move1;

      // who goes first?
      bool pc_goes_first = true;
      
      if (pc_move->priority > wild_move->priority) {
        pc_goes_first = true;
      } else if (wild_move->priority > pc_move->priority) {
        pc_goes_first = false;
      } else {
        // if priority is tied, go off of level-adjusted speed
        if (pc_active->get_speed() > p->get_speed()) {
          pc_goes_first = true;
        } else if (p->get_speed() > pc_active->get_speed()) {
          pc_goes_first = false;
        } else {
          // speed is also tied, pick random random
          pc_goes_first = (rand() % 2 == 0);
        }
      }

      // pc attacks first
      if (pc_goes_first) {
        // pc attack first
        int pc_dmg = calculate_damage(pc_active, p, pc_move);
        // a 0 is a "miss"
        if (pc_dmg == 0) {
          attron(COLOR_PAIR(1));
          mvprintw(22, 2, "Your %s's %s missed!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str());
          attroff(COLOR_PAIR(1));
        }
        else {
          p->reduce_hp(pc_dmg);
          attron(COLOR_PAIR(1));
          mvprintw(22, 2, "Your %s used %s! Dealt %d damage!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str(), pc_dmg);
          attroff(COLOR_PAIR(1));
        }
        getch();

        // wild pokemon attacks second
        if (p->get_hp() > 0) {
          int wild_dmg = calculate_damage(p, pc_active, wild_move);
          if (wild_dmg == 0) {
            attron(COLOR_PAIR(7));
            mvprintw(23, 2, "Wild %s's %s missed!", p->get_species_identifier().c_str(), wild_move->identifier.c_str());
            attroff(COLOR_PAIR(7)); // make it easier to tell enemy moves
          } else {
            pc_active->reduce_hp(wild_dmg);
            attron(COLOR_PAIR(7));
            mvprintw(23, 2, "Wild %s's %s dealt %d damage!", p->get_species_identifier().c_str(), wild_move->identifier.c_str(), wild_dmg);
            attroff(COLOR_PAIR(7));
          }
          getch();
        }

      }
      else {
        // wild pokemon attacks first
        int wild_dmg = calculate_damage(p, pc_active, wild_move);
        if (wild_dmg == 0) {
          attron(COLOR_PAIR(7));
          mvprintw(22, 2, "Wild %s's %s missed!", p->get_species_identifier().c_str(), wild_move->identifier.c_str());
          attroff(COLOR_PAIR(7));
        } else {
          pc_active->reduce_hp(wild_dmg);
          attron(COLOR_PAIR(7));
          mvprintw(22, 2, "Wild %s's %s dealt %d damage!", p->get_species_identifier().c_str(), wild_move->identifier.c_str(), wild_dmg);
          attroff(COLOR_PAIR(7));
        }
        getch();

        // pc attacks second
        if (pc_active->get_hp() > 0) {
          int pc_dmg = calculate_damage(pc_active, p, pc_move);
          if (pc_dmg == 0) {
            attron(COLOR_PAIR(1));
            mvprintw(23, 2, "Your %s's %s missed!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str());
            attroff(COLOR_PAIR(1));
          } else {
            p->reduce_hp(pc_dmg);
            attron(COLOR_PAIR(1));
            mvprintw(23, 2, "Your %s used %s! Dealt %d damage!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str(), pc_dmg);
            attroff(COLOR_PAIR(1));
          }
          getch();
        }
      }
    }

    // RUN
    else if (choice == '4') {
      escape_attempts++;
      int speed_wild = std::max(1, (p->get_speed() % 256));
      int odds_escape = ((pc_active->get_speed() * 32) / speed_wild) + (30 * escape_attempts);
      
      if (odds_escape > 255 || (rand() % 256) < odds_escape) {
        mvprintw(22, 2, "Escape worked!");
        getch();
        battle_is_active = false;
      } 
      else {
        mvprintw(22, 2, "Escape failed!");
        getch();
        // wild pokemon attacks since escape failed
        int wild_dmg = calculate_damage(p, pc_active, p->move1);
        pc_active->reduce_hp(wild_dmg);
        attron(COLOR_PAIR(7));
        mvprintw(23 , 2, "Wild %s attacked you! Dealt %d damage.", p->get_species_identifier().c_str(), wild_dmg);
        attroff(COLOR_PAIR(7));
        getch();
      }
    }

    // BAG
    else if (choice == '2') {
      clear();
      mvprintw(2, 2, "ITEM BAG");
      mvprintw(4, 2, "1) Potion (x%d) - Heals 20 HP", pc->potions);
      mvprintw(5, 2, "2) Revive (x%d) - Revives fainted Pokemon", pc->revives);
      mvprintw(6, 2, "3) Pokeball (x%d) - Catches wild Pokemon", pc->pokeballs);
      mvprintw(8, 2, "0) Cancel");
      refresh();

      int bag_choice = getch();
      // POTION
      if (bag_choice == '1') { 
        if (pc->potions > 0) {
          pc->potions--;
          pc_active->hp += 20; // heals 20
          if (pc_active->hp > pc_active->max_hp) pc_active->hp = pc_active->max_hp; // caps at max_hp
          
          mvprintw(10, 2, "Potion Consumed! %s's HP is now %d/%d", pc_active->get_species_identifier().c_str(), pc_active->hp, pc_active->max_hp);
          getch();

          // using an item takes a turn, so make pokemon attack next
          int wild_dmg = calculate_damage(p, pc_active, p->move1);
          pc_active->reduce_hp(wild_dmg);
          attron(COLOR_PAIR(7));
          mvprintw(11, 2, "Wild %s attacked you! Dealt %d damage.", p->get_species_identifier().c_str(), wild_dmg);
          attroff(COLOR_PAIR(7));
          getch();
        } 
        else {
          mvprintw(10, 2, "No more Potions!");
          getch();
        }
      }
      // REVIVE
      else if (bag_choice == '2') {
        // revive first found pokemon
        if (pc->revives > 0) {
        bool revived_someone = false;
        for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
          if (pc->trained_pokemon[i].hp <= 0) {
            pc->trained_pokemon[i].hp = pc->trained_pokemon[i].max_hp / 2; // revives to 50% hp
            pc->revives--;
            mvprintw(10, 2, "Revived %s to half HP!", pc->trained_pokemon[i].get_species_identifier().c_str());
            revived_someone = true;
            break;
          }
        }
        if (!revived_someone) {
          mvprintw(10, 2, "None of your Pokemon are fainted.");
        }
        else {
          // player turn consumed, so pokemon attacks
          int wild_dmg = calculate_damage(p, pc_active, p->move1);
          pc_active->reduce_hp(wild_dmg);
          attron(COLOR_PAIR(7));
          mvprintw(11, 2, "Wild %s attacked you! Dealt %d damage.", p->get_species_identifier().c_str(), wild_dmg);
          attroff(COLOR_PAIR(7));
        }
        getch();
        }
        else {
          mvprintw(10, 2, "No more Revives!");
          getch();
        }
      }
      // POKEBALL
      else if (bag_choice == '3') { 
        if (pc->pokeballs > 0) {
          pc->pokeballs--;
          mvprintw(10, 2, "You try to catch %s!",p->get_species_identifier().c_str() );
          getch();

          // can only have 6 trained pokemon
          if (pc->trained_pokemon.size() < 6) {
            mvprintw(11, 2, "%s was caught!", p->get_species_identifier().c_str());
            pc->trained_pokemon.push_back(*p); // add wild pokemon to trained pokemon
            getch();
            battle_is_active = false;
          }
          else {
            // if partiy is full, pokemon escaepes
            mvprintw(11, 2, "Your party is full!");
            mvprintw(12, 2, "The wild %s broke free and ran away!", p->get_species_identifier().c_str());
            getch();
            battle_is_active = false;
          }
        }
        else {
          mvprintw(10, 2, "No more Pokeballs!");
          getch();
        }
      }
    }

    // POKEMON
    else if (choice == '3') {
      // call helper, allow_cancel is true since not forced by a faint
      Pokemon* selected = choose_trained_pokemon(pc, pc_active, true, "TRAINED POKEMON");
      
      if (selected != NULL) {
        pc_active = selected;
        clear();
        mvprintw(15, 2, "Get in there, %s!", pc_active->get_species_identifier().c_str());
        refresh();
        getch();

        // switch takes a turn, so make wild enemy attack
        int wild_dmg = calculate_damage(p, pc_active, p->move1);
        pc_active->reduce_hp(wild_dmg);
        attron(COLOR_PAIR(7));
        mvprintw(16, 2, "Wild %s attacked you! Dealt %d damage.", p->get_species_identifier().c_str(), wild_dmg);
        attroff(COLOR_PAIR(7));
        getch();
      }
    }

    // check fainting condtions at the end of the turn
    if (pc_active->get_hp() <= 0) {
      move(22, 0); clrtoeol();
      move(23, 0); clrtoeol();
      mvprintw(22, 2, "Your %s fainted!", pc_active->get_species_identifier().c_str());
      getch();
      
      // check if player has any useable Pokemon left
      bool has_conscious_pokemon = false;
      for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
        if (pc->trained_pokemon[i].hp > 0) {
          has_conscious_pokemon = true;
          break;
        }
      }

      if (!has_conscious_pokemon) {
        clear();
        mvprintw(2, 2, "You have no more usable Pokemon!");
        mvprintw(4, 2, "You got knocked out!");
        refresh();
        getch();
        battle_is_active = false;
      }
      else {
        std::string title = pc_active->get_species_identifier() + " Fainted! Choose a replacement";
        
        pc_active = choose_trained_pokemon(pc, pc_active, false, title.c_str());
        
        clear();
        mvprintw(14, 2, "Get in there, %s!", pc_active->get_species_identifier().c_str());
        refresh();
        getch();
      }
    }
  }
  clear();
}

// return the correct movement cost based on character type and terrain type
int32_t get_terrain_cost(character_type_t ct, terrain_type_t tt) {
  switch(ct) {
    // for the pc
    case char_pc:
      switch(tt) {

        case ter_path: return 10;
        case ter_mart: return 10;
        case ter_center: return 10;
        case ter_grass: return 20;
        case ter_clearing: return 10;
        //case ter_gate: return 10; Perhaps just take 10 off of "stamina" or whatever cost is 
        // implemented next ONCE the player takes a gate?
        default: return INT_MAX;
      }

    //for a hiker
    case char_hiker:
      switch(tt) {
        // Bldr Tree Path PMart PCntr TGras SGras Mtn Forest Water Gate
        //   ∞    ∞   10   50    50     15    10  15    15     ∞     ∞
        //case ter_boulder: return 15; leaving as INT_MAX cost so I don't have to redo the border
        //case ter_tree: return 15;
        case ter_path: return 10;
        case ter_mart: return 50;
        case ter_center: return 50;
        case ter_grass: return 20;
        case ter_clearing: return 10;
        case ter_mountain: return 15;
        case ter_forest: return 15;
        default: return INT_MAX; // Water, Gate should be "infinity/very large large"
      }
      
    // for a rival
    case char_rival:
      switch(tt) {
        case ter_path: return 15;
        case ter_mart: return 15;
        case ter_center: return 15;
        case ter_grass: return 15;
        case ter_clearing: return 15;
        default: return INT_MAX;
      }
    
    // for a swimmer
    case char_swimmer:
      switch(tt) {
        case ter_water: return 7;
        default: return INT_MAX;
      }

    // for OTHER (if add more)
    case char_pacer:
    case char_wanderer:
    case char_sentry:
    case char_explorer:

      switch(tt) {
        case ter_path: return 10;
        case ter_mart: return 50;
        case ter_center: return 50;
        case ter_grass: return 20;
        case ter_clearing: return 10;
        default: return INT_MAX;
      }

    default: return INT_MAX;
  }
}


typedef struct queue_node {
  int x, y;
  struct queue_node *next;
} queue_node_t;

static int32_t path_cmp(const void *key, const void *with) {
  return ((path_t *) key)->cost - ((path_t *) with)->cost;
}

static int32_t edge_penalty(uint8_t x, uint8_t y)
{
  return (x == 1 || y == 1 || x == MAP_X - 2 || y == MAP_Y - 2) ? 2 : 1;
}

static void dijkstra_path(map_t *m, pair_t from, pair_t to)
{
  static path_t path[MAP_Y][MAP_X], *p;
  static uint32_t initialized = 0;
  heap_t h;
  uint32_t x, y;

  if (!initialized) {
    for (y = 0; y < MAP_Y; y++) {
      for (x = 0; x < MAP_X; x++) {
        path[y][x].pos[dim_y] = y;
        path[y][x].pos[dim_x] = x;
      }
    }
    initialized = 1;
  }
  
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      path[y][x].cost = INT_MAX;
    }
  }

  path[from[dim_y]][from[dim_x]].cost = 0;

  heap_init(&h, path_cmp, NULL);

  for (y = 1; y < MAP_Y - 1; y++) {
    for (x = 1; x < MAP_X - 1; x++) {
      path[y][x].hn = heap_insert(&h, &path[y][x]);
    }
  }

  // cpp doesnt like void pointers! must explicitly cast its pointer type
  while ((p = (path_t *) heap_remove_min(&h))) {
    p->hn = NULL;

    if ((p->pos[dim_y] == to[dim_y]) && p->pos[dim_x] == to[dim_x]) {
      for (x = to[dim_x], y = to[dim_y];
           (x != from[dim_x]) || (y != from[dim_y]);
           p = &path[y][x], x = p->from[dim_x], y = p->from[dim_y]) {
        mapxy(x, y) = ter_path;
        heightxy(x, y) = 0;
      }
      heap_delete(&h);
      return;
    }

    if ((path[p->pos[dim_y] - 1][p->pos[dim_x]    ].hn) &&
        (path[p->pos[dim_y] - 1][p->pos[dim_x]    ].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x], p->pos[dim_y] - 1)))) {
      path[p->pos[dim_y] - 1][p->pos[dim_x]    ].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x], p->pos[dim_y] - 1));
      path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y] - 1]
                                           [p->pos[dim_x]    ].hn);
    }
    if ((path[p->pos[dim_y]    ][p->pos[dim_x] - 1].hn) &&
        (path[p->pos[dim_y]    ][p->pos[dim_x] - 1].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x] - 1, p->pos[dim_y])))) {
      path[p->pos[dim_y]][p->pos[dim_x] - 1].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x] - 1, p->pos[dim_y]));
      path[p->pos[dim_y]    ][p->pos[dim_x] - 1].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y]    ][p->pos[dim_x] - 1].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y]    ]
                                           [p->pos[dim_x] - 1].hn);
    }
    if ((path[p->pos[dim_y]    ][p->pos[dim_x] + 1].hn) &&
        (path[p->pos[dim_y]    ][p->pos[dim_x] + 1].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x] + 1, p->pos[dim_y])))) {
      path[p->pos[dim_y]][p->pos[dim_x] + 1].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x] + 1, p->pos[dim_y]));
      path[p->pos[dim_y]    ][p->pos[dim_x] + 1].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y]    ][p->pos[dim_x] + 1].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y]    ]
                                           [p->pos[dim_x] + 1].hn);
    }
    if ((path[p->pos[dim_y] + 1][p->pos[dim_x]    ].hn) &&
        (path[p->pos[dim_y] + 1][p->pos[dim_x]    ].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x], p->pos[dim_y] + 1)))) {
      path[p->pos[dim_y] + 1][p->pos[dim_x]    ].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x], p->pos[dim_y] + 1));
      path[p->pos[dim_y] + 1][p->pos[dim_x]    ].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y] + 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y] + 1]
                                           [p->pos[dim_x]    ].hn);
    }
  }
}

static int build_paths(map_t *m)
{
  pair_t from, to;

  from[dim_x] = 1;
  to[dim_x] = MAP_X - 2;
  from[dim_y] = m->w;
  to[dim_y] = m->e;

  dijkstra_path(m, from, to);

  from[dim_y] = 1;
  to[dim_y] = MAP_Y - 2;
  from[dim_x] = m->n;
  to[dim_x] = m->s;

  dijkstra_path(m, from, to);

  return 0;
}

static int gaussian[5][5] = {
  {  1,  4,  7,  4,  1 },
  {  4, 16, 26, 16,  4 },
  {  7, 26, 41, 26,  7 },
  {  4, 16, 26, 16,  4 },
  {  1,  4,  7,  4,  1 }
};
static int smooth_height(map_t *m)
{
  int32_t i, x, y;
  int32_t s, t, p, q;
  queue_node_t *head, *tail, *tmp;
  /*  FILE *out;*/
  uint8_t height[MAP_Y][MAP_X];

  memset(&height, 0, sizeof (height));

  /* Seed with some values */
  for (i = 1; i < 255; i += 20) {
    do {
      x = rand() % MAP_X;
      y = rand() % MAP_Y;
    } while (height[y][x]);
    height[y][x] = i;
    if (i == 1) {
      head = tail = new queue_node_t();
    } else {
      tail->next = new queue_node_t();
      tail = tail->next;
    }
    tail->next = NULL;
    tail->x = x;
    tail->y = y;
  }

  /*
  out = fopen("seeded.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&height, sizeof (height), 1, out);
  fclose(out);
  */
  
  /* Diffuse the vaules to fill the space */
  while (head) {
    x = head->x;
    y = head->y;
    i = height[y][x];

    if (x - 1 >= 0 && y - 1 >= 0 && !height[y - 1][x - 1]) {
      height[y - 1][x - 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y - 1;
    }
    if (x - 1 >= 0 && !height[y][x - 1]) {
      height[y][x - 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y;
    }
    if (x - 1 >= 0 && y + 1 < MAP_Y && !height[y + 1][x - 1]) {
      height[y + 1][x - 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y + 1;
    }
    if (y - 1 >= 0 && !height[y - 1][x]) {
      height[y - 1][x] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x;
      tail->y = y - 1;
    }
    if (y + 1 < MAP_Y && !height[y + 1][x]) {
      height[y + 1][x] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x;
      tail->y = y + 1;
    }
    if (x + 1 < MAP_X && y - 1 >= 0 && !height[y - 1][x + 1]) {
      height[y - 1][x + 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y - 1;
    }
    if (x + 1 < MAP_X && !height[y][x + 1]) {
      height[y][x + 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y;
    }
    if (x + 1 < MAP_X && y + 1 < MAP_Y && !height[y + 1][x + 1]) {
      height[y + 1][x + 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y + 1;
    }

    tmp = head;
    head = head->next;
    delete tmp;
  }

  /* And smooth it a bit with a gaussian convolution */
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      for (s = t = p = 0; p < 5; p++) {
        for (q = 0; q < 5; q++) {
          if (y + (p - 2) >= 0 && y + (p - 2) < MAP_Y &&
              x + (q - 2) >= 0 && x + (q - 2) < MAP_X) {
            s += gaussian[p][q];
            t += height[y + (p - 2)][x + (q - 2)] * gaussian[p][q];
          }
        }
      }
      m->height[y][x] = t / s;
    }
  }
  /* Let's do it again, until it's smooth like Kenny G. */
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      for (s = t = p = 0; p < 5; p++) {
        for (q = 0; q < 5; q++) {
          if (y + (p - 2) >= 0 && y + (p - 2) < MAP_Y &&
              x + (q - 2) >= 0 && x + (q - 2) < MAP_X) {
            s += gaussian[p][q];
            t += height[y + (p - 2)][x + (q - 2)] * gaussian[p][q];
          }
        }
      }
      m->height[y][x] = t / s;
    }
  }

  /*
  out = fopen("diffused.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&height, sizeof (height), 1, out);
  fclose(out);

  out = fopen("smoothed.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->height, sizeof (m->height), 1, out);
  fclose(out);
  */

  return 0;
}

static void find_building_location(map_t *m, pair_t p)
{
  do {
    p[dim_x] = rand() % (MAP_X - 3) + 1;
    p[dim_y] = rand() % (MAP_Y - 3) + 1;

    if ((((mapxy(p[dim_x] - 1, p[dim_y]    ) == ter_path)     &&
          (mapxy(p[dim_x] - 1, p[dim_y] + 1) == ter_path))    ||
         ((mapxy(p[dim_x] + 2, p[dim_y]    ) == ter_path)     &&
          (mapxy(p[dim_x] + 2, p[dim_y] + 1) == ter_path))    ||
         ((mapxy(p[dim_x]    , p[dim_y] - 1) == ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] - 1) == ter_path))    ||
         ((mapxy(p[dim_x]    , p[dim_y] + 2) == ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 2) == ter_path)))   &&
        (((mapxy(p[dim_x]    , p[dim_y]    ) != ter_mart)     &&
          (mapxy(p[dim_x]    , p[dim_y]    ) != ter_center)   &&
          (mapxy(p[dim_x] + 1, p[dim_y]    ) != ter_mart)     &&
          (mapxy(p[dim_x] + 1, p[dim_y]    ) != ter_center)   &&
          (mapxy(p[dim_x]    , p[dim_y] + 1) != ter_mart)     &&
          (mapxy(p[dim_x]    , p[dim_y] + 1) != ter_center)   &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 1) != ter_mart)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 1) != ter_center))) &&
        (((mapxy(p[dim_x]    , p[dim_y]    ) != ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y]    ) != ter_path)     &&
          (mapxy(p[dim_x]    , p[dim_y] + 1) != ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 1) != ter_path)))) {
          break;
    }
  } while (1);
}

static int place_pokemart(map_t *m, int all_maps_x, int all_maps_y)
{
  int total_dist = abs(all_maps_x - 200) + abs(all_maps_y - 200);
  int prob = ((-45 * total_dist) / 200) + 50;

  if (total_dist == 0 || (rand() % 100) < prob) {
    pair_t p;

    find_building_location(m, p);

    mapxy(p[dim_x]    , p[dim_y]    ) = ter_mart;
    mapxy(p[dim_x] + 1, p[dim_y]    ) = ter_mart;
    mapxy(p[dim_x]    , p[dim_y] + 1) = ter_mart;
    mapxy(p[dim_x] + 1, p[dim_y] + 1) = ter_mart;
  }

  return 0;
}

static int place_center(map_t *m, int all_maps_x, int all_maps_y)
{  
  int total_dist = abs(all_maps_x - 200) + abs(all_maps_y - 200);
  int prob = ((-45 * total_dist) / 200) + 50;

  if (total_dist == 0 || (rand() % 100) < prob) {
    pair_t p;
    find_building_location(m, p);

    mapxy(p[dim_x]    , p[dim_y]    ) = ter_center;
    mapxy(p[dim_x] + 1, p[dim_y]    ) = ter_center;
    mapxy(p[dim_x]    , p[dim_y] + 1) = ter_center;
    mapxy(p[dim_x] + 1, p[dim_y] + 1) = ter_center;
  }

  return 0;
}

/* Chooses tree or boulder for border cell.  Choice is biased by dominance *
 * of neighboring cells.                                                   */
static terrain_type_t border_type(map_t *m, int32_t x, int32_t y)
{
  int32_t p, q;
  int32_t r, t;
  int32_t miny, minx, maxy, maxx;
  
  r = t = 0;
  
  miny = y - 1 >= 0 ? y - 1 : 0;
  maxy = y + 1 <= MAP_Y ? y + 1: MAP_Y;
  minx = x - 1 >= 0 ? x - 1 : 0;
  maxx = x + 1 <= MAP_X ? x + 1: MAP_X;

  for (q = miny; q < maxy; q++) {
    for (p = minx; p < maxx; p++) {
      if (q != y || p != x) {
        if (m->map[q][p] == ter_mountain ||
            m->map[q][p] == ter_boulder) {
          r++;
        } else if (m->map[q][p] == ter_forest ||
                   m->map[q][p] == ter_tree) {
          t++;
        }
      }
    }
  }
  
  if (t == r) {
    return rand() & 1 ? ter_boulder : ter_tree;
  } else if (t > r) {
    if (rand() % 10) {
      return ter_tree;
    } else {
      return ter_boulder;
    }
  } else {
    if (rand() % 10) {
      return ter_boulder;
    } else {
      return ter_tree;
    }
  }
}

static int map_terrain(map_t *m, uint8_t n, uint8_t s, uint8_t e, uint8_t w)
{
  int32_t i, x, y;
  queue_node_t *head, *tail, *tmp;
  //  FILE *out;
  int num_grass, num_clearing, num_mountain, num_forest, num_water, num_total;
  terrain_type_t type;
  int added_current = 0;
  
  num_grass = rand() % 4 + 2;
  num_clearing = rand() % 4 + 2;
  num_mountain = rand() % 2 + 1;
  num_forest = rand() % 2 + 1;
  num_water = rand() % 2 + 1;
  num_total = num_grass + num_clearing + num_mountain + num_forest + num_water;

  memset(&m->map, 0, sizeof (m->map));

  /* Seed with some values */
  for (i = 0; i < num_total; i++) {
    do {
      x = rand() % MAP_X;
      y = rand() % MAP_Y;
    } while (m->map[y][x]);
    if (i == 0) {
      type = ter_grass;
    } else if (i == num_grass) {
      type = ter_clearing;
    } else if (i == num_grass + num_clearing) {
      type = ter_mountain;
    } else if (i == num_grass + num_clearing + num_mountain) {
      type = ter_forest;
    } else if (i == num_grass + num_clearing + num_mountain + num_forest) {
      type = ter_water;
    }
    m->map[y][x] = type;
    if (i == 0) {
      head = tail = new queue_node_t();
    } else {
      tail->next = new queue_node_t();
      tail = tail->next;
    }
    tail->next = NULL;
    tail->x = x;
    tail->y = y;
  }

  /*
  out = fopen("seeded.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->map, sizeof (m->map), 1, out);
  fclose(out);
  */
  
  /* Diffuse the vaules to fill the space */
  while (head) {
    x = head->x;
    y = head->y;
    i = m->map[y][x];
    
    if (x - 1 >= 0 && !m->map[y][x - 1]) {
      if ((rand() % 100) < 80) {
        m->map[y][x - 1] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x - 1;
        tail->y = y;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (y - 1 >= 0 && !m->map[y - 1][x]) {
      if ((rand() % 100) < 20) {
        m->map[y - 1][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y - 1;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (y + 1 < MAP_Y && !m->map[y + 1][x]) {
      if ((rand() % 100) < 20) {
        m->map[y + 1][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y + 1;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (x + 1 < MAP_X && !m->map[y][x + 1]) {
      if ((rand() % 100) < 80) {
        m->map[y][x + 1] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x + 1;
        tail->y = y;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    added_current = 0;
    tmp = head;
    head = head->next;
    delete tmp;
  }

  /*
  out = fopen("diffused.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->map, sizeof (m->map), 1, out);
  fclose(out);
  */
  
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      if (y == 0 || y == MAP_Y - 1 ||
          x == 0 || x == MAP_X - 1) {
        mapxy(x, y) = type = border_type(m, x, y);
      }
    }
  }

  m->n = n;
  m->s = s;
  m->e = e;
  m->w = w;

  mapxy(n,         0        ) = ter_path;
  mapxy(n,         1        ) = ter_path;
  mapxy(s,         MAP_Y - 1) = ter_path;
  mapxy(s,         MAP_Y - 2) = ter_path;
  mapxy(0,         w        ) = ter_path;
  mapxy(1,         w        ) = ter_path;
  mapxy(MAP_X - 1, e        ) = ter_path;
  mapxy(MAP_X - 2, e        ) = ter_path;

  return 0;
}

static int place_boulders(map_t *m)
{
  int i;
  int x, y;

  for (i = 0; i < MIN_BOULDERS || rand() % 100 < BOULDER_PROB; i++) {
    y = rand() % (MAP_Y - 2) + 1;
    x = rand() % (MAP_X - 2) + 1;
    if (m->map[y][x] != ter_forest && m->map[y][x] != ter_path) {
      m->map[y][x] = ter_boulder;
    }
  }

  return 0;
}

static int place_trees(map_t *m)
{
  int i;
  int x, y;
  
  for (i = 0; i < MIN_TREES || rand() % 100 < TREE_PROB; i++) {
    y = rand() % (MAP_Y - 2) + 1;
    x = rand() % (MAP_X - 2) + 1;
    if (m->map[y][x] != ter_mountain &&
        m->map[y][x] != ter_path     &&
        m->map[y][x] != ter_water) {
      m->map[y][x] = ter_tree;
    }
  }

  return 0;
}

static int new_map(map_t *m, int all_maps_x, int all_maps_y, int n, int s, int e, int w)
{
  smooth_height(m);
  map_terrain(m, n, s, e, w);
  place_boulders(m);
  place_trees(m);
  build_paths(m);
  place_pokemart(m, all_maps_x, all_maps_y);
  place_center(m, all_maps_x, all_maps_y);

  return 0;
}

// prints out the map, with including characters that "that sit on top" of the map to be presented (not actually
// affecting the real map tile!)
static void print_map_with_chars(map_t *m, character_t *pc, character_t *npcs, int num_trainers)
{
  int x, y, i;
  int is_char;
  
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      is_char = 0;

      if (pc->x == x && pc->y == y) {
        attron(COLOR_PAIR(8));
        mvaddch(y + 1, x, '@');
        attroff(COLOR_PAIR(8));
        continue;
      }

      for(i = 0; i < num_trainers; i++) {
        if (npcs[i].x == x && npcs[i].y == y) {
          char npc_char;
          switch (npcs[i].type) {
            case char_hiker: npc_char = 'h'; break;
            case char_rival: npc_char = 'r'; break;
            case char_swimmer: npc_char = 'i'; break;
            case char_pacer: npc_char = 'p'; break;
            case char_wanderer: npc_char = 'w'; break;
            case char_sentry: npc_char = 's'; break;
            case char_explorer: npc_char = 'e'; break;
            default: break;
          }

          attron(COLOR_PAIR(7));
          mvaddch(y + 1, x, npc_char);
          attroff(COLOR_PAIR(7));
          is_char = 1;
          break;
        }
      }

      if (is_char) continue;

      char ter_char;
      int color = 0;

      switch (m->map[y][x]) {
      case ter_boulder:
      case ter_mountain:
        ter_char = '%';
        color = 4;
        break;
      case ter_tree:
      case ter_forest:
        ter_char = '^';
        color = 2;
        break;
      case ter_path:
        ter_char = '#';
        color = 5;
        break;
      case ter_mart:
        ter_char = 'M';
        color = 6;
        break;
      case ter_center:
        ter_char = 'C';
        color = 6;
        break;
      case ter_grass:
        ter_char = ':';
        color = 1;
        break;
      case ter_clearing:
        ter_char = '.';
        color = 1;
        break;
      case ter_water:
        ter_char = '~';
        color = 3;
        break;
      default: break;
      }

      if (color) attron(COLOR_PAIR(color));
      mvaddch(y + 1, x, ter_char);
      if (color) attroff(COLOR_PAIR(color));
    }
  }
  // goes to terminal screen
  refresh();
}

// helper that checks if a tile is occupied (returns 1 if true, 0 if false)
static int get_occupied_npc_idx(character_t *pc, character_t *npcs, int num_trainers, int x, int y) {
  if (pc->x == x && pc->y == y) return -10; //-10 for pc (means pc is there)
  for (int i = 0; i < num_trainers; i++) {
    if (npcs[i].x == x && npcs[i].y == y) return i; // return specific index of npc (which npc)
  }
  return -1; // empty
}





// randomly picks x & y coords until a suitable spot is find for the character that was given, and "places" them there.
// (actually updates the character's coordinates in the respective character struct)
void place_entity(map_t *m, character_t *c, character_t *pc, character_t *npcs, int num_placed) {
  int x, y;
  while (1) {
    // only look for a space to place WITHIN the map, excluding the borders
    x = rand() % (MAP_X - 2) + 1;
    y = rand() % (MAP_Y - 2) + 1;

    // make sure they're not spawning in a building/another npc
    if (get_occupied_npc_idx(pc, npcs, num_placed, x, y) != -1) continue;

    if (get_terrain_cost(c->type, m->map[y][x]) != INT_MAX) {
      c->x = x;
      c->y = y;
      c->spawn_terrain = m->map[y][x];


      do {
        c->dir_x = (rand() % 3) - 1;
        c->dir_y = (rand() % 3) - 1;
      } while (c->dir_x == 0 && c->dir_y == 0);
      break;
    }

  }
}


// find shortest path from pc to all tiles, taking character type into account. break early if 
// queue leftovers are INT_MAX since those tiles are unreachable
static int dijkstra_npc_dist(map_t *m, pair_t from, int dist[MAP_Y][MAP_X], character_type_t ct)
{
  static path_t path[MAP_Y][MAP_X], *p;
  static uint32_t initialized = 0;
  heap_t h;
  uint32_t x, y;

  if (!initialized) {
    for(y = 0; y < MAP_Y; y++) {
      for (x = 0; x < MAP_X; x++) {
        path[y][x].pos[dim_y] = y;
        path[y][x].pos[dim_x] = x;
      }
    }
    initialized = 1;
  }

  for(y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      path[y][x].cost = INT_MAX;
      path[y][x].hn = NULL;
    }
  }

  path[from[dim_y]][from[dim_x]].cost = 0;

  heap_init(&h, path_cmp, NULL);

  for (y = 1; y < MAP_Y - 1; y++) {
    for (x = 1; x < MAP_X - 1; x++) {
      if (get_terrain_cost(ct, m->map[y][x]) != INT_MAX) {
        path[y][x].hn = heap_insert(&h, &path[y][x]);
      }
    }
  }

  while ((p = (path_t *) heap_remove_min(&h))) {
    p->hn = NULL;

    // if shortest path is infinity/very large (INT_MAX) in the queue, those tiles are unreachable and stop search
    if (p->cost ==INT_MAX) break;

    int dx, dy;


    for (dy = -1; dy <= 1; dy++) {
      for (dx = -1; dx <= 1; dx++) {
        if (dx == 0 && dy == 0) continue;
        int nx = p->pos[dim_x] + dx;
        int ny = p->pos[dim_y] + dy;


        if (nx >= 1 && nx < MAP_X - 1 && ny >= 1 && ny < MAP_Y - 1) {
          int32_t move_cost = get_terrain_cost(ct, m->map[ny][nx]);
          if (move_cost != INT_MAX && path[ny][nx].hn) {
            if (path[ny][nx].cost > p->cost + move_cost) {
              path[ny][nx].cost = p->cost + move_cost;
              heap_decrease_key_no_replace(&h, path[ny][nx].hn);
            }
          }
        }
      }
    }
  }

  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      dist[y][x] = path[y][x].cost;
    }
  }
  heap_delete(&h);
  return 0;
}

/*
// takes a completed distance array, and prints the distances. unreachable (INT_MAX) are printed with blank spaces 
static void print_dist_map(int dist[MAP_Y][MAP_X]) {
  int x, y;
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      if (dist[y][x] == INT_MAX) {
        printf("   ");
      } 
      else {
        printf("%02d ", dist[y][x] % 100);
      }
    }
    printf("\n");
  }

}
  */



// prints coords (external, from -200 to 200 range)
void print_coords(int all_maps_x, int all_maps_y) {
  printf("Current Position: (%d, %d)\n", all_maps_x-200, (all_maps_y - 200));
}

// comparator for the heap/priority queue. Sorts characters by next turn time so the character w/
// the lowest cost will move first. Tiebreaker w/ seq_num
static int32_t character_turn_cmp(const void *key, const void *with) {
  int32_t turn_diff = ((character_t *) key)->next_turn - ((character_t *) with) -> next_turn;
  if (turn_diff == 0) {
    return ((character_t *) key) ->seq_num - ((character_t *) with) ->seq_num;
  }
  return turn_diff;
}


void display_trainer_battle(character_t *pc, character_t *npc) {
  bool battle_is_active = true;

  // initialize pc trained pokemon
  Pokemon *pc_active = NULL;
  for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
    if (pc->trained_pokemon[i].get_hp() > 0) {
      pc_active = &pc->trained_pokemon[i];
      break;
    }
  }

  // initalize npcs pokemon
  Pokemon *npc_active = NULL;
  for (size_t i = 0; i < npc->trained_pokemon.size(); i++) {
    if (npc->trained_pokemon[i].get_hp() > 0) {
      npc_active = &npc->trained_pokemon[i];
      break;
    }
  }

  if (!pc_active || !npc_active) {
    return;
  }

  clear();
  mvprintw(2, 2, "You are fighting a trainer! There team cosists of:");
  // loop through and dispay their team
  for (size_t i = 0; i < npc->trained_pokemon.size(); i++) {
    Pokemon *p = &npc->trained_pokemon[i];
    int row_offset = 3 + (i * 3);
    
    // don't go off the small terminal
    if (row_offset > 20) break; 
    
    mvprintw(row_offset, 2, "Pokemon %lu: %s (Lv: %d)", i + 1, p->get_species_identifier().c_str(), p->get_level());
    
    attron(COLOR_PAIR(7)); // make red
    mvprintw(row_offset + 1, 4, "HP: %d | ATK: %d | DEF: %d | SPD: %d", 
      p->get_hp(), p->get_attack(), p->get_defense(), p->get_speed());
    attroff(COLOR_PAIR(7));
    
    mvprintw(row_offset + 2, 4, "Moves: %s, %s", 
      p->get_move1_identifier().c_str(), 
      p->get_move2_identifier() != "" ? p->get_move2_identifier().c_str() : "None");
  }

  mvprintw(22, 2, "Press any key to start the battle!");
  refresh();
  getch();

  while (battle_is_active) {
    clear();
    mvprintw(2, 2, "TRAINER BATTLE");
    
    // npc pokemon ui (same as wild encounter)
    mvprintw(4, 2, "Enemy %s (LVL %d)", npc_active->get_species_identifier().c_str(), npc_active->get_level());
    attron(COLOR_PAIR(7)); 
    mvprintw(5, 2, "HP: %d/%d", npc_active->get_hp(), npc_active->max_hp);
    attroff(COLOR_PAIR(7));
    mvprintw(6, 2, "ATK: %d    | DEF: %d", npc_active->get_attack(), npc_active->get_defense());
    mvprintw(7, 2, "SP.ATK: %d | SP.DEF: %d", npc_active->get_special_attack(), npc_active->get_special_defense());
    mvprintw(8, 2, "SPEED: %d", npc_active->get_speed());

    // display the moves
    mvprintw(10, 2, "Moves:");
    mvprintw(11, 2, "- %s", npc_active->get_move1_identifier().c_str());
    if (npc_active->get_move2_identifier() != "") {
      mvprintw(12, 2, "- %s", npc_active->get_move2_identifier().c_str());
    }

    // pc pokemon ui
    attron(COLOR_PAIR(1)); 
    mvprintw(14, 2, "Your %s (LVL %d) - HP: %d/%d", 
      pc_active->get_species_identifier().c_str(), pc_active->get_level(), 
      pc_active->get_hp(), pc_active->max_hp);
    mvprintw(15, 2, "ATK: %d    | DEF: %d", pc_active->get_attack(), pc_active->get_defense());
    mvprintw(16, 2, "SP.ATK: %d | SP.DEF: %d", pc_active->get_special_attack(), pc_active->get_special_defense());
    mvprintw(17, 2, "SPEED: %d", pc_active->get_speed());
    attroff(COLOR_PAIR(1)); 

    mvprintw(19, 2, "Your options are:");
    mvprintw(20, 4, "1) Fight    2) Bag");
    mvprintw(21, 4, "3) Pokemon  4) Run");
    refresh();

    int choice = getch();

    // FIGHT
    if (choice == '1') {
      // move selection sub-menu
      clear();
      mvprintw(2, 2, "Choose %s's move to use:", pc_active->get_species_identifier().c_str());
      
      attron(COLOR_PAIR(1));
      mvprintw(4, 4, "1) %s", pc_active->get_move1_identifier().c_str());
      
      bool has_move2 = (pc_active->get_move2_identifier() != "");
      if (has_move2) {
        mvprintw(5, 4, "2) %s", pc_active->get_move2_identifier().c_str());
      }
      attroff(COLOR_PAIR(1));
      
      mvprintw(7, 4, "0) Cancel");
      refresh();

      int move_choice = getch();
      const moves* pc_move = NULL;

      if (move_choice == '1') {
        pc_move = pc_active->move1;
      }
      else if (move_choice == '2' && has_move2) {
        pc_move = pc_active->move2;
      }
      else {
        continue;
      }
      const moves* npc_move = (rand() % 2 == 0 && npc_active->move2) ? npc_active->move2 : npc_active->move1;

      // who goes first?
      bool pc_goes_first = true;
      if (pc_move->priority > npc_move->priority) {
        pc_goes_first = true;
      } else if (npc_move->priority > pc_move->priority) {
        pc_goes_first = false;
      } else {
        if (pc_active->get_speed() > npc_active->get_speed()) {
          pc_goes_first = true;
        } else if (npc_active->get_speed() > pc_active->get_speed()) {
          pc_goes_first = false;
        } else {
          pc_goes_first = (rand() % 2 == 0);
        }
      }

      // run turns based on order
      if (pc_goes_first) {
        // pc attack first
        int pc_dmg = calculate_damage(pc_active, npc_active, pc_move);
        if (pc_dmg == 0) {
          attron(COLOR_PAIR(1));
          mvprintw(22, 2, "Your %s's %s missed!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str());
          attroff(COLOR_PAIR(1));
        } else {
          npc_active->reduce_hp(pc_dmg);
          attron(COLOR_PAIR(1));
          mvprintw(22, 2, "Your %s used %s! Dealt %d damage!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str(), pc_dmg);
          attroff(COLOR_PAIR(1));
        }
        getch();

        // npc attacks second
        if (npc_active->get_hp() > 0) {
          int npc_dmg = calculate_damage(npc_active, pc_active, npc_move);
          if (npc_dmg == 0) {
            attron(COLOR_PAIR(7));
            mvprintw(23, 2, "Enemy %s's %s missed!", npc_active->get_species_identifier().c_str(), npc_move->identifier.c_str());
            attroff(COLOR_PAIR(7)); 
          } else {
            pc_active->reduce_hp(npc_dmg);
            attron(COLOR_PAIR(7));
            mvprintw(23, 2, "Enemy %s's %s dealt %d damage!", npc_active->get_species_identifier().c_str(), npc_move->identifier.c_str(), npc_dmg);
            attroff(COLOR_PAIR(7));
          }
          getch();
        }

      } else {
        // npc attacks first
        int npc_dmg = calculate_damage(npc_active, pc_active, npc_move);
        if (npc_dmg == 0) {
          attron(COLOR_PAIR(7));
          mvprintw(22, 2, "Enemy %s's %s missed!", npc_active->get_species_identifier().c_str(), npc_move->identifier.c_str());
          attroff(COLOR_PAIR(7));
        } else {
          pc_active->reduce_hp(npc_dmg);
          attron(COLOR_PAIR(7));
          mvprintw(22, 2, "Enemy %s's %s dealt %d damage!", npc_active->get_species_identifier().c_str(), npc_move->identifier.c_str(), npc_dmg);
          attroff(COLOR_PAIR(7));
        }
        getch();

        // pc attacks second
        if (pc_active->get_hp() > 0) {
          int pc_dmg = calculate_damage(pc_active, npc_active, pc_move);
          if (pc_dmg == 0) {
            attron(COLOR_PAIR(1));
            mvprintw(23, 2, "Your %s's %s missed!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str());
            attroff(COLOR_PAIR(1));
          } else {
            npc_active->reduce_hp(pc_dmg);
            attron(COLOR_PAIR(1));
            mvprintw(23, 2, "Your %s used %s! Dealt %d damage!", pc_active->get_species_identifier().c_str(), pc_move->identifier.c_str(), pc_dmg);
            attroff(COLOR_PAIR(1));
          }
          getch();
        }
      }
    }

    // RUN
    else if (choice == '4') {
      mvprintw(22, 2, "Can't run away from a trainer battle!");
      getch();
      continue; 
    }
    
    // BAG
    else if (choice == '2') {
      clear();
      mvprintw(2, 2, "ITEM BAG");
      mvprintw(4, 2, "1) Potion (x%d) - Heals 20 HP", pc->potions);
      mvprintw(5, 2, "2) Revive (x%d) - Revives fainted Pokemon", pc->revives);
      mvprintw(6, 2, "3) Pokeball (x%d) - Catches wild Pokemon", pc->pokeballs);
      mvprintw(8, 2, "0) Cancel");
      refresh();

      int bag_choice = getch();
      
      // POTION
      if (bag_choice == '1') { 
        if (pc->potions > 0) {
          pc->potions--;
          pc_active->hp += 20; 
          if (pc_active->hp > pc_active->max_hp) pc_active->hp = pc_active->max_hp; 
          
          mvprintw(10, 2, "Potion Consumed! %s's HP is now %d/%d", pc_active->get_species_identifier().c_str(), pc_active->hp, pc_active->max_hp);
          getch();

          // using an item takes a turn, so make npc attack next
          const moves* npc_move = (rand() % 2 == 0 && npc_active->move2) ? npc_active->move2 : npc_active->move1;
          int npc_dmg = calculate_damage(npc_active, pc_active, npc_move);
          pc_active->reduce_hp(npc_dmg);
          attron(COLOR_PAIR(7));
          mvprintw(11, 2, "Enemy %s attacked you! Dealt %d damage.", npc_active->get_species_identifier().c_str(), npc_dmg);
          attroff(COLOR_PAIR(7));
          getch();
        } 
        else {
          mvprintw(10, 2, "No more Potions!");
          getch();
        }
      }
      // REVIVE
      else if (bag_choice == '2') {
        if (pc->revives > 0) {
          bool revived_someone = false;
          for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
            if (pc->trained_pokemon[i].hp <= 0) {
              pc->trained_pokemon[i].hp = pc->trained_pokemon[i].max_hp / 2; 
              pc->revives--;
              mvprintw(10, 2, "Revived %s to half HP!", pc->trained_pokemon[i].get_species_identifier().c_str());
              revived_someone = true;
              break;
            }
          }
          if (!revived_someone) {
            mvprintw(10, 2, "None of your Pokemon are fainted.");
          }
          else {
            // using an item takes a turn, so make npc attack next
            const moves* npc_move = (rand() % 2 == 0 && npc_active->move2) ? npc_active->move2 : npc_active->move1;
            int npc_dmg = calculate_damage(npc_active, pc_active, npc_move);
            pc_active->reduce_hp(npc_dmg);
            attron(COLOR_PAIR(7));
            mvprintw(11, 2, "Enemy %s attacked you! Dealt %d damage.", npc_active->get_species_identifier().c_str(), npc_dmg);
            attroff(COLOR_PAIR(7));
          }
          getch();
        }
        else {
          mvprintw(10, 2, "No more Revives!");
          getch();
        }
      }
      // POKEBALL
      else if (bag_choice == '3') {
        mvprintw(10, 2, "Can only use Pokeballs on wild pokemon!");
        getch();
        continue;
      }
      else {
        continue; // Cancelled bag
      }
    }

    // POKEMON (switch)
    else if (choice == '3') {
      Pokemon* selected = choose_trained_pokemon(pc, pc_active, true, "TRAINED POKEMON");
      if (selected != NULL) {
        pc_active = selected;
        clear();
        mvprintw(15, 2, "Get in there, %s!", pc_active->get_species_identifier().c_str());
        refresh();
        getch();

        // switch takes a turn, so make npc attack
        const moves* npc_move = (rand() % 2 == 0 && npc_active->move2) ? npc_active->move2 : npc_active->move1;
        int npc_dmg = calculate_damage(npc_active, pc_active, npc_move);
        pc_active->reduce_hp(npc_dmg);
        attron(COLOR_PAIR(7));
        mvprintw(16, 2, "Enemy %s attacked you! Dealt %d damage.", npc_active->get_species_identifier().c_str(), npc_dmg);
        attroff(COLOR_PAIR(7));
        getch();
      }
    }


    // did npc feint?
    if (npc_active->get_hp() <= 0) {
      move(22, 0); clrtoeol();
      move(23, 0); clrtoeol();
      mvprintw(22, 2, "Enemy %s fainted!", npc_active->get_species_identifier().c_str());
      getch();
      
      bool npc_has_more = false;
      for (size_t i = 0; i < npc->trained_pokemon.size(); i++) {
        if (npc->trained_pokemon[i].get_hp() > 0) {
          npc_active = &npc->trained_pokemon[i];
          npc_has_more = true;
          mvprintw(23, 2, "Trainer sent out %s!", npc_active->get_species_identifier().c_str());
          getch();
          break;
        }
      }

      if (!npc_has_more) {
        clear();
        mvprintw(2, 2, "You defeated the Trainer!");
        refresh();
        getch();
        npc->defeated = 1;
        battle_is_active = false;
      }
    }

    // pc faint?
    if (battle_is_active && pc_active->get_hp() <= 0) {
      move(22, 0); clrtoeol();
      move(23, 0); clrtoeol();
      mvprintw(22, 2, "Your %s fainted!", pc_active->get_species_identifier().c_str());
      getch();

      bool has_conscious_pokemon = false;
      for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
        if (pc->trained_pokemon[i].hp > 0) {
          has_conscious_pokemon = true;
          break;
        }
      }

      if (!has_conscious_pokemon) {
        clear();
        mvprintw(2, 2, "You have no more usable Pokemon!");
        mvprintw(4, 2, "You got knocked out!");
        refresh();
        getch();
        battle_is_active = false;
      }
      else {
        std::string title =  pc_active->get_species_identifier() + " Fainted! Choose a replacement";
        pc_active = choose_trained_pokemon(pc, pc_active, false, title.c_str());
        
        clear();
        mvprintw(14, 2, "Get in there, %s!", pc_active->get_species_identifier().c_str());
        refresh();
        getch();
      }
    }
  }
  clear();
}

// finds then updates new locations of a given npc. takes into consideration the types of npcs, and doesn't let them walk off-map
static void move_npc(map_t *m, character_t *npc, character_t *pc, character_t *npcs, int num_trainers,
  int hiker_dist[MAP_Y][MAP_X], int rival_dist[MAP_Y][MAP_X]) {
    // just make the npc stop moving if it is defeated
    if (npc -> defeated) {
      return;
    }

    int nx = npc->x;
    int ny = npc->y;
    int min_dist = INT_MAX;

    if (npc->type == char_hiker || npc->type == char_rival) {
      int (*dist_map)[MAP_X] = (npc->type == char_hiker) ? hiker_dist : rival_dist;

      for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
          if (dx == 0 && dy == 0) continue;
          int check_x = npc->x + dx;
          int check_y = npc->y + dy;

          // if either of these are true, then shouldn't be able to move that way (don't go on border)
          if (check_x <= 0 || check_x >= MAP_X -1 || check_y <= 0 || check_y >= MAP_Y -1) {
            continue;
          }
          int occupant = get_occupied_npc_idx(pc, npcs, num_trainers, check_x, check_y);
          if (occupant == -10) {
            if (!npc->defeated) {
              display_trainer_battle(pc, npc);
              npc->defeated = 1;

              clear();
              print_map_with_chars(m, pc, npcs, num_trainers);
            }
            return;
          }

          // of no occupant (empty) then look for shortest path on empty spaces
          if (occupant == -1 && 
            dist_map[check_y][check_x] < min_dist &&
            get_terrain_cost(npc->type, m->map[check_y][check_x]) != INT_MAX) {
              min_dist = dist_map[check_y][check_x];
              nx = check_x;
              ny = check_y;
          }
        }
      }
    }

    else if (npc->type == char_pacer || npc->type == char_explorer || npc->type == char_wanderer) {
      int check_x = npc->x + npc->dir_x;
      int check_y = npc->y + npc->dir_y;
      int can_move = 1;

      // if either of these are true, then shouldn't be able to move that way (don't go on border)
      if (check_x <= 0 || check_x >= MAP_X -1 || check_y <= 0 || check_y >= MAP_Y -1) {
        can_move = 0;
      }

      else {
        int occupant = get_occupied_npc_idx(pc, npcs, num_trainers, check_x, check_y);

        // npc is trying to move on player, start a battle
        if (occupant == -10) {
          if (!npc->defeated) {
            display_trainer_battle(pc, npc);
            npc->defeated = 1;

            //clear();
            //print_map_with_chars(m, pc, npcs, num_trainers);
            // this marks the end(?) of what should be seperate "battle" function...
          }
          can_move = 0; // don't actually go on top of PC
        }
          
        // otherwise the space is occupied by another NPC, don't go there
        else if (occupant >= 0) {
          can_move = 0;
        }
      
        else if (get_terrain_cost(npc->type, m->map[check_y][check_x]) == INT_MAX) can_move = 0;
        else if (npc->type == char_wanderer && m->map[check_y][check_x] != npc->spawn_terrain) can_move = 0;
      }

      if (can_move) {
        nx = check_x;
        ny = check_y;
      }
      else { 
        // at this point, pacer should flip direction
        if (npc->type == char_pacer) {
          npc->dir_x *= -1;
          npc->dir_y *= -1;
        }
        else {
          do {
            npc->dir_x = (rand() % 3) -1;
            npc->dir_y = (rand() % 3) -1;
          } while (npc->dir_x == 0 && npc->dir_y == 0);
        }
      }
    }
    npc->x = nx;
    npc->y = ny;
}

// to calculate relative distances and deal with scrolling of the interface that shows when hit 't'
static void display_npc_list(character_t *npcs, int num_trainers, character_t *pc, int max_display) {
  int offset = 0;
  int key;

  while(1) {
    clear();
    mvprintw(0, 0, "NPC list (UP/DOWN arrows to scroll, ESC to exit) (first num is just npc idx, meaningless)");

    for (int i = 0; i < max_display && i + offset < num_trainers; i++) {
      int npc_idx = i + offset;
      int dx = npcs[npc_idx].x - pc->x;
      int dy = npcs[npc_idx].y - pc->y;
      char dir_y[6] = "";
      char dir_x[6] = "";
      
      if (dy < 0) strcpy(dir_y, "north");
      if (dy > 0) strcpy(dir_y, "south");
      if (dx < 0) strcpy(dir_x, "west");
      if (dx > 0) strcpy(dir_x, "east");

      char icon;
      switch (npcs[npc_idx].type) {
        case char_hiker: icon = 'h'; break;
        case char_rival: icon = 'r'; break;
        case char_swimmer: icon = 'i'; break;
        case char_pacer: icon = 'p'; break;
        case char_wanderer: icon = 'w'; break;
        case char_sentry: icon = 's'; break;
        case char_explorer: icon = 'e'; break;
        default: break;
      }

      if (dy == 0 && dx == 0) {
         mvprintw(i + 2, 0, "%d, %c, on top of PC", npc_idx, icon);
      } else if (dy == 0) {
         mvprintw(i + 2, 0, "%d, %c, %d %s", npc_idx, icon, abs(dx), dir_x);
      } else if (dx == 0) {
         mvprintw(i + 2, 0, "%d, %c, %d %s", npc_idx, icon, abs(dy), dir_y);
      } else {
         mvprintw(i + 2, 0, "%d, %c, %d %s and %d %s", npc_idx, icon, abs(dy), dir_y, abs(dx), dir_x);
      }
    }
    refresh();
    
    key = getch();
    if (key == 27) break; // 27 decmial = ESC ASCII 
    if (key == KEY_UP && offset > 0) offset--; // by enabling keypad w/ keypad(stdscr, TRUE), can use KEY_LEFT, KEY_UP, etc...
    if (key == KEY_DOWN && offset + max_display < num_trainers) offset++;
  }
}

// for user to choose first of 3 random
void choose_starter_pokemon(character_t *pc) {
  clear();
  
  // create 3 random pokemon that are level 1
  Pokemon starter1(1);
  Pokemon starter2(1);
  Pokemon starter3(1);

  mvprintw(2, 2, "Choose your starting Pokemon:");
  
  // show the available pokemons, and their stats hp, attack, defense, special_attack, special_defense, speed;
  mvprintw(4, 2, "1: %s (HP: %d, ATK: %d, DEF: %d, SP.ATK: %d, SP.DEF: %d, SPEED: %d)", 
    starter1.get_species_identifier().c_str(), starter1.get_hp(), starter1.get_attack(),
    starter1.get_defense(), starter2.get_special_attack(), starter2.get_special_defense(),starter1.get_speed());

  mvprintw(5, 2, "1: %s (HP: %d, ATK: %d, DEF: %d, SP.ATK: %d, SP.DEF: %d, SPEED: %d)", 
    starter2.get_species_identifier().c_str(), starter2.get_hp(), 
    starter2.get_attack(), starter2.get_defense(), starter2.get_special_attack(), starter2.get_special_defense(),
    starter2.get_speed());

  mvprintw(6, 2, "1: %s (HP: %d, ATK: %d, DEF: %d, SP.ATK: %d, SP.DEF: %d, SPEED: %d)", 
    starter3.get_species_identifier().c_str(), starter3.get_hp(), 
    starter3.get_attack(), starter3.get_defense(), starter2.get_special_attack(), starter2.get_special_defense(),
    starter3.get_speed());
  
  mvprintw(8, 2, "Press 1, 2, or 3 to select.");
  refresh();

  // wait for correct input
  int choice = 0;
  while (choice != '1' && choice != '2' && choice != '3') {
    choice = getch();
  }

  // add selected to trained pokemon vector
  if (choice == '1') pc->trained_pokemon.push_back(starter1);
  else if (choice == '2') pc->trained_pokemon.push_back(starter2);
  else if (choice == '3') pc->trained_pokemon.push_back(starter3);

  // display what they chose
  clear();
  mvprintw(2, 2, "You chose %s!", pc->trained_pokemon[0].get_species_identifier().c_str());
  mvprintw(4, 2, "Press any key to continue...");
  refresh();
  getch();
  clear();
}

// generate pokemeon for npc trainers
void generate_npc_trained_pokemon(character_t *npc, int cur_x, int cur_y) {

  // calculate level based on distance
  int d = abs(cur_x - 200) + abs(cur_y - 200);
  int min_level, max_level;

  if (d <= 200) {
    min_level = 1;
    max_level = (d <= 1) ? 1 : d / 2;
  } 
  else {
    min_level = (d - 200) / 2;
    max_level = 100;
  }

  // make sure levels are within 1 and 100
  if (min_level < 1) min_level = 1;
  if (max_level < 1) max_level = 1;
  if (min_level > 100) min_level = 100;
  if (max_level > 100) max_level = 100;

  int level = (min_level == max_level) ? min_level : (rand() % (max_level - min_level + 1)) + min_level;
  npc->trained_pokemon.push_back(Pokemon(level));

  // 60% for (n+1)th pokemon, up to a max of 6
  while (npc->trained_pokemon.size() < 6 && (rand() % 100) < 60) {
    level = (min_level == max_level) ? min_level : (rand() % (max_level - min_level + 1)) + min_level;
    npc->trained_pokemon.push_back(Pokemon(level));
  }
}

// for pc to use a bag out of combat
void open_bag_out_of_battle(character_t *pc) {
  bool in_bag = true;
  
  while (in_bag) {
    clear();
    mvprintw(2, 2, "BAG (OUT OF BATTLE)");
    mvprintw(4, 2, "1) Potion (x%d) - Heals 20 HP", pc->potions);
    mvprintw(5, 2, "2) Revive (x%d) - Revives fainted Pokemon", pc->revives);
    mvprintw(6, 2, "3) Pokeballs (x%d) - (Can't use outside battle)", pc->pokeballs);
    mvprintw(8, 2, "0) Exit Bag");
    refresh();

    int choice = getch();

    if (choice == '0') {
      in_bag = false;
    } 
    // POTION
    else if (choice == '1') {
      if (pc->potions > 0) {
        Pokemon* target = choose_trained_pokemon(pc, NULL, true, "Use Potion on which one?", false); //not a revive!
        if (target) {
          if (target->hp == target->max_hp) {
            mvprintw(15, 2, "%s's HP is already full!", target->get_species_identifier().c_str());
            getch();
          }
          else {
            target->hp += 20;
            if (target->hp > target->max_hp) target->hp = target->max_hp;
            pc->potions--;
            mvprintw(15, 2, "Healed %s! HP is now %d/%d.", target->get_species_identifier().c_str(), target->hp, target->max_hp);
            getch();
          }
        }
      }
      else {
        mvprintw(10, 2, "No more Potions!");
        getch();
      }
    } 
    // REVIVE
    else if (choice == '2') {
      if (pc->revives > 0) {
        Pokemon* target = choose_trained_pokemon(pc, NULL, true, "Use Revive on which one?", true); // is a revive, last param = true
        if (target) {
          target->hp = target->max_hp / 2; // revive to half hp
          pc->revives--;
          mvprintw(15, 2, "%s was revived!", target->get_species_identifier().c_str());
          getch();
        }
      } else {
        mvprintw(10, 2, "No more Revives!");
        getch();
      }
    } 
    
    // POKEBALL
    else if (choice == '3') {
      mvprintw(10, 2, "Can't use Pokeballs outside of battle!");
      getch();
    }
  }
  clear();
}

// should heal all trained pokemon
void visit_pokecenter(character_t *pc) {
  clear();
  mvprintw(2, 2, "POKEMON CENTER ");
  
  // set hp of pokemon to max (fully heal)
  for (size_t i = 0; i < pc->trained_pokemon.size(); i++) {
    pc->trained_pokemon[i].hp = pc->trained_pokemon[i].max_hp;
  }
  
  mvprintw(3, 2, "Your Pokemon are fully healed!");
  mvprintw(4, 2, "Press any key to exit...");
  refresh();
  getch();
  clear();
}

// should refill supplies
void visit_pokemart(character_t *pc) {
  clear();
  mvprintw(2, 2, "POKEMART");

  // set to max limits
  pc->revives = MAX_REVIVES; 
  pc->potions = MAX_POTIONS;
  pc->pokeballs = MAX_POKEBALLS;

  mvprintw(3, 2, "Inventory Restocked!");
  
  mvprintw(5, 2, "- Potions: %d", pc->potions);
  mvprintw(6, 2, "- Revives: %d", pc->revives);
  mvprintw(7, 2, "- Pokeballs: %d", pc->pokeballs);
  
  mvprintw(8, 2, "Press any key to exit...");
  refresh();
  getch();
  clear();
}



int main(int argc, char *argv[]) {
  
  std::string db_path = "/share/cs327/pokedex/pokedex/data/csv/";
  std::ifstream test_file(db_path + "pokemon.csv"); 

  if (!test_file) {
    // for looking under $HOME/.poke327/
    const char* home_dir = getenv("HOME");
    if(home_dir != NULL) {
      // like $HOME/.poke327/pokedex/data/csv/pokemon_moves.csv
      db_path = std::string(home_dir) + "/.poke327/pokedex/data/csv/";
    }
  }
  else {
    test_file.close();
  }

  pokemon_db = parse_csv<pokemon>(db_path + "pokemon.csv");
  moves_db = parse_csv<moves>(db_path + "moves.csv");
  pokemon_moves_db = parse_csv<pokemon_moves>(db_path + "pokemon_moves.csv");
  pokemon_species_db = parse_csv<pokemon_species>(db_path + "pokemon_species.csv");
  experience_db = parse_csv<experience>(db_path + "experience.csv");
  type_names_db = parse_csv<type_names>(db_path + "type_names.csv");
  pokemon_stats_db = parse_csv<pokemon_stats>(db_path + "pokemon_stats.csv");
  stats_db = parse_csv<stats>(db_path + "stats.csv");
  pokemon_types_db = parse_csv<pokemon_types>(db_path + "pokemon_types.csv");


  if (argc > 1) {
    std::string arg = argv[1];

    // this keeps assignemnt1.07's purpose, but unless declared, like <./poke327 moves>, then this will be ignored
    if (arg == "pokemon" || arg == "moves" || arg == "pokemon_moves" ||
        arg == "pokemon_species" || arg == "experience" || arg == "type_names" ||
        arg == "pokemon_stats" || arg == "stats" || arg == "pokemon_types") {

      if (arg == "pokemon") {
        parse_csv<pokemon>(db_path + "pokemon.csv", true);
      }
      else if (arg == "moves") {
        parse_csv<moves>(db_path + "moves.csv", true);
      }
      else if (arg == "pokemon_moves") {
        parse_csv<pokemon_moves>(db_path + "pokemon_moves.csv", true);
      }
      else if (arg == "pokemon_species") {
        parse_csv<pokemon_species>(db_path + "pokemon_species.csv", true);
      }
      else if (arg == "experience") {
        parse_csv<experience>(db_path + "experience.csv", true);
      }
      else if (arg == "type_names") {
        parse_csv<type_names>(db_path + "type_names.csv", true);
      }
      else if (arg == "pokemon_stats") {
        parse_csv<pokemon_stats>(db_path + "pokemon_stats.csv", true);
      }
      else if (arg == "stats") {
        parse_csv<stats>(db_path + "stats.csv", true);
      }
      else if (arg == "pokemon_types") {
        parse_csv<pokemon_types>(db_path + "pokemon_types.csv", true);
      }

      return 0;
    } 
  }

  struct timeval tv;
  uint32_t seed;
  int num_trainers = 10;
  int seed_was_given = 0; // 1 = true, 0 = false

  
  // go through all command line arguments starting at idx1
  for (int i = 1; i < argc; i++) {
    if (strcmp(argv[i], "--numtrainers") == 0 && i + 1 < argc) {
      num_trainers = strtol(argv[i+1], NULL, 10);
      i++;
    }
    else {
      // if not switch, then treat as a given seed
      errno = 0;
      seed = strtol(argv[i], NULL, 10);
      if (!isdigit(argv[i][0]) || errno) {
        fprintf(stderr, "Invalid seed value on command line.\n");
        return -1;
      }
      seed_was_given = 1;
    }
  }

  if (!seed_was_given) {
    gettimeofday(&tv, NULL);
    seed = (tv.tv_usec ^ (tv.tv_sec << 20)) & 0xffffffff;
  }

  printf("Using seed: %u\n", seed);
  srand(seed);

  // ncurses stuff
  initscr();
  start_color();
  curs_set(0);

  // color pairs (id, fg color, bg color)
  init_pair(1, COLOR_GREEN, COLOR_BLACK); // tall grass/clearings,
  init_pair(2, COLOR_WHITE, COLOR_BLACK); // trees // ncurses only has 8 colors, so brown didn't work. might change trees only later
  init_pair(3, COLOR_BLUE, COLOR_BLACK); // water
  init_pair(4, COLOR_WHITE, COLOR_BLACK); // boulders/mountains
  init_pair(5, COLOR_YELLOW, COLOR_BLACK); // paths/gates
  init_pair(6, COLOR_CYAN, COLOR_BLACK); // pokemarts/centers
  init_pair(7, COLOR_RED, COLOR_BLACK); // trainers
  init_pair(8, COLOR_MAGENTA, COLOR_BLACK); // PC
  // maybe do other ones later?

  noecho();
  raw(); // makes input unbuffered (don't need to press enter)
  keypad(stdscr, TRUE); // enable use of arrow keys


  map_t *all_maps[401][401];
  int cur_y = 200, cur_x = 200;
  //char input[30];
  //int fly_x, fly_y; 
  int hiker_dist[MAP_Y][MAP_X];
  int rival_dist[MAP_Y][MAP_X];
  //int swimmer_dist[MAP_Y][MAP_X];
  
  for(int y = 0; y < 401; y++) {
    for(int x = 0; x < 401; x++) {
      all_maps[y][x] = NULL;
    }
  }

  // allocate memory for first map
  all_maps[cur_y][cur_x] = new map_t();

  // store the first map with random exits
  new_map(all_maps[cur_y][cur_x], cur_x, cur_y, 
    rand() % 78 + 1, rand() % 78 + 1, rand() % 19 + 1, rand() % 19 + 1);  
  

  // initialize pc
  character_t pc;
  pc.type = char_pc;
  pc.next_turn = 0;
  pc.seq_num = 0;
  pc.x = -1;
  pc.y = -1;

  // initialize nps for first map
  all_maps[cur_y][cur_x]->num_trainers = num_trainers;
  all_maps[cur_y][cur_x]->npcs = new character_t[num_trainers];
  place_entity(all_maps[cur_y][cur_x], &pc, &pc, all_maps[cur_y][cur_x]->npcs, 0);

  for (int i = 0; i < num_trainers; i++) {
    if (i == 0) all_maps[cur_y][cur_x]->npcs[i].type = char_hiker;
    else if (i == 1 && num_trainers > 1) all_maps[cur_y][cur_x]->npcs[i].type = char_rival;
    // once both exist, then start placing random npc's from hiker to most recent (explorer)
    else all_maps[cur_y][cur_x]->npcs[i].type = (character_type_t) ((rand() % 7) + 1); 

    all_maps[cur_y][cur_x]->npcs[i].next_turn = 0;
    all_maps[cur_y][cur_x]->npcs[i].seq_num = i + 1;
    all_maps[cur_y][cur_x]->npcs[i].x = -1;
    all_maps[cur_y][cur_x]->npcs[i].y = -1;
    all_maps[cur_y][cur_x]->npcs[i].defeated = 0; // make them NPCs start undefeated

    // add random pokemon to the trainer
    generate_npc_trained_pokemon(&all_maps[cur_y][cur_x]->npcs[i], cur_x, cur_y);

    place_entity(all_maps[cur_y][cur_x], &all_maps[cur_y][cur_x]->npcs[i], &pc, all_maps[cur_y][cur_x]->npcs, i);
  }

  pair_t pc_position = {(uint8_t)pc.x, (uint8_t)pc.y};

  // only hiker/rival are input here since they chase the player
  dijkstra_npc_dist(all_maps[cur_y][cur_x], pc_position, hiker_dist, char_hiker);
  dijkstra_npc_dist(all_maps[cur_y][cur_x], pc_position, rival_dist, char_rival);

  heap_t turn_queue;
  heap_init(&turn_queue, character_turn_cmp, NULL);

  heap_insert(&turn_queue, &pc);
  for (int i = 0; i < num_trainers; i++) {
    heap_insert(&turn_queue , &all_maps[cur_y][cur_x]->npcs[i]);
  }

  character_t *c;



  choose_starter_pokemon(&pc);

  int game_is_quit = 0;

  while(!game_is_quit && (c = (character_t*) heap_remove_min(&turn_queue))) {
    character_t *cur_npcs = all_maps[cur_y][cur_x]->npcs;
    int cur_num_trainers = all_maps[cur_y][cur_x]->num_trainers;

    if (c->type == char_pc) {
      print_map_with_chars(all_maps[cur_y][cur_x], &pc, cur_npcs, cur_num_trainers);

      int move_is_valid = 0;

      while (!move_is_valid && !game_is_quit) {
        if (all_maps[cur_y][cur_x]->map[pc.y][pc.x] == ter_mart) {
          mvprintw(0, 0, "On a PokeMart, press '>' to enter");
        }
        else if (all_maps[cur_y][cur_x]->map[pc.y][pc.x] == ter_center) {
          mvprintw(0, 0, "On a PokeCenter, press '>' to enter");
        }
        // print the world coords
        mvprintw(22, 0, "world position: (%d, %d)    ", cur_x - 200, cur_y - 200);
        refresh();

        int key = getch();
        int nx = pc.x;
        int ny = pc.y;

        move(0, 0); // clears the top line of text
        clrtoeol(); // erases current line from cursor's position to end of line

        switch(key) {
          case '7': case 'y': nx--; ny--; move_is_valid = 1; break;
          case '8': case 'k': case 'w': ny--; move_is_valid = 1; break; 
          case '9': case 'u': nx++; ny--; move_is_valid = 1; break;
          case '6': case 'l': case 'd': nx++; move_is_valid = 1; break;
          case '3': case 'n': nx++; ny++; move_is_valid = 1; break;
          case '2': case 'j': case 's': ny++; move_is_valid = 1; break;
          case '1': case 'b': nx--; ny++; move_is_valid = 1; break;
          case '4': case 'h': case 'a': nx--; move_is_valid = 1; break;
          case '5': case ' ': case '.':
            move_is_valid = 1; 
            mvprintw(0, 0, "waited 1 turn");
            break;
          case 'B': open_bag_out_of_battle(&pc); 
            print_map_with_chars(all_maps[cur_y][cur_x], &pc, cur_npcs, cur_num_trainers);
            refresh();
            break;
          case 'Q': game_is_quit = 1; break;
          case '>': 
            if (all_maps[cur_y][cur_x]->map[pc.y][pc.x] == ter_mart) {
              clear();
              visit_pokemart(&pc);
              print_map_with_chars(all_maps[cur_y][cur_x], &pc, cur_npcs, cur_num_trainers);
              refresh();
            }
            else if (all_maps[cur_y][cur_x]->map[pc.y][pc.x] == ter_center) {
              clear();
              visit_pokecenter(&pc);
              print_map_with_chars(all_maps[cur_y][cur_x], &pc, cur_npcs, cur_num_trainers);
              refresh();
            }
            else {
              mvprintw(0, 0, "Not on building.");
            }
            break;
          case 't':
            // call npc list function (with 8 npcs as max to display)
            display_npc_list(cur_npcs, cur_num_trainers, &pc, 8);
            clear();
            print_map_with_chars(all_maps[cur_y][cur_x], &pc, cur_npcs, cur_num_trainers);
            break;


          // for flying
          case 'f':
            move(0, 0);
            clrtoeol();
            mvprintw(0, 0, "Enter coords to fly to (x y, no commas): ");
            refresh();
            echo();
            

            int fly_x, fly_y;
            // buffered input, getch() not good for this
            if(scanw("%d %d", &fly_x, &fly_y) != 2) {
              noecho();
              move(0, 0);
              clrtoeol();
              mvprintw(0, 0, "Invalid input format! only enter (x y). Press any key to continue.");
              refresh();
              getch();
              break;
            }
            noecho();

            if (fly_x + 200 >= 0 && fly_x + 200 <= 400 && fly_y + 200 >= 0 && fly_y + 200 <= 400) {
              cur_x = fly_x + 200;
              cur_y = fly_y + 200;

              //below is very similar as if the character was moving between gates (furhter down in main)
              if (all_maps[cur_y][cur_x] == NULL) {
        
                all_maps[cur_y][cur_x] = new map_t();

                int n = (cur_y > 0 && all_maps[cur_y - 1][cur_x]) ? all_maps[cur_y - 1][cur_x]->s : (rand() % (MAP_X - 4) + 2);
                int s = (cur_y < 400 && all_maps[cur_y + 1][cur_x]) ? all_maps[cur_y + 1][cur_x]->n : (rand() % (MAP_X - 4) + 2);
                int e = (cur_x < 400 && all_maps[cur_y][cur_x + 1]) ? all_maps[cur_y][cur_x + 1]->w : (rand() % (MAP_Y - 4) + 2);
                int w = (cur_x > 0 && all_maps[cur_y][cur_x - 1]) ? all_maps[cur_y][cur_x - 1]->e : (rand() % (MAP_Y - 4) + 2);

                if (cur_y == 0) n = 0;
                if (cur_y == 400) s = 0;
                if (cur_x == 0) w = 0;
                if (cur_x == 400) e = 0;

                new_map(all_maps[cur_y][cur_x], cur_x, cur_y, n, s, e, w);
                // create the npc's
                all_maps[cur_y][cur_x]->num_trainers = num_trainers;
                all_maps[cur_y][cur_x]->npcs = new character_t[num_trainers];


                for (int i = 0; i < num_trainers; i++) {
                  if (i == 0) all_maps[cur_y][cur_x]->npcs[i].type = char_hiker;
                  else if (i == 1 && num_trainers > 1) all_maps[cur_y][cur_x]->npcs[i].type = char_rival;
                  else all_maps[cur_y][cur_x]->npcs[i].type = (character_type_t) ((rand() % 7) + 1);

                  // maintain the turn queues
                  all_maps[cur_y][cur_x]->npcs[i].next_turn = pc.next_turn;
                  all_maps[cur_y][cur_x]->npcs[i].seq_num = i + 1;
                  all_maps[cur_y][cur_x]->npcs[i].x = -1;
                  all_maps[cur_y][cur_x]->npcs[i].y = -1;
                  all_maps[cur_y][cur_x]->npcs[i].defeated = 0;

                  generate_npc_trained_pokemon(&all_maps[cur_y][cur_x]->npcs[i], cur_x, cur_y);

                  place_entity(all_maps[cur_y][cur_x], &all_maps[cur_y][cur_x]->npcs[i], &pc, all_maps[cur_y][cur_x]->npcs, i);
                }
              }

              // find place character on first road found
              int placed = 0;
              for (int y = 1; y < MAP_Y -1 && !placed; y++) {
                for(int x = 1; x < MAP_X -1; x++) {
                  if (get_terrain_cost(char_pc, all_maps[cur_y][cur_x]->map[y][x]) < INT_MAX) {
                    pc.x = x;
                    pc.y = y;
                    placed = 1;
                    break;
                  }
                }
              }
              move_is_valid = 1;

              nx = pc.x;
              ny = pc.y;

              // must delete the old queue and load the new map characters in it ("want a turn queue per map")
              heap_delete(&turn_queue);
              heap_init(&turn_queue, character_turn_cmp, NULL);
              for (int i = 0; i < all_maps[cur_y][cur_x]->num_trainers; i++) {
                heap_insert(&turn_queue, &all_maps[cur_y][cur_x]->npcs[i]);
              }
            }
            else {
              move(0, 0);
              clrtoeol();
              mvprintw(0, 0, "coords out of bounds! Press any key to continue");
              refresh();
              getch();
            }
            break;

          
          // for when user presses a key that isn't "defined"
          default:
            mvprintw(0, 0, "Key pressed: %d (decimal ASCII)", key);
            refresh();
            break;
        }

        if (move_is_valid && !game_is_quit) {
          if (nx >= 0 && nx < MAP_X && ny >= 0 && ny < MAP_Y && 
            get_terrain_cost(char_pc, all_maps[cur_y][cur_x]->map[ny][nx]) != INT_MAX) {

              // check if player on a gate
              if(nx == 0 || nx == MAP_X -1 || ny == 0 || ny == MAP_Y -1) {
                int next_x = cur_x;
                int next_y = cur_y;

                if (nx == 0) next_x--;
                if (nx == MAP_X -1) next_x++;
                if (ny == 0) next_y --;
                if (ny == MAP_Y - 1) next_y++;

                // if within bounds of the world
                if (next_x >= 0 && next_x <= 400 && next_y >= 0 && next_y <= 400) {
                  cur_x = next_x;
                  cur_y = next_y;

                  // if entering a new, undiscovered map
                  if (all_maps[cur_y][cur_x] == NULL) {
                    all_maps[cur_y][cur_x] = new map_t();

                    int n = (cur_y > 0 && all_maps[cur_y - 1][cur_x]) ? all_maps[cur_y - 1][cur_x]->s : (rand() % (MAP_X - 4) + 2);
                    int s = (cur_y < 400 && all_maps[cur_y + 1][cur_x]) ? all_maps[cur_y + 1][cur_x]->n : (rand() % (MAP_X - 4) + 2);
                    int e = (cur_x < 400 && all_maps[cur_y][cur_x + 1]) ? all_maps[cur_y][cur_x + 1]->w : (rand() % (MAP_Y - 4) + 2);
                    int w = (cur_x > 0 && all_maps[cur_y][cur_x - 1]) ? all_maps[cur_y][cur_x - 1]->e : (rand() % (MAP_Y - 4) + 2);

                    new_map(all_maps[cur_y][cur_x], cur_x, cur_y, n, s, e, w);
                    // create the npc's
                    all_maps[cur_y][cur_x]->num_trainers = num_trainers;
                    all_maps[cur_y][cur_x]->npcs = new character_t[num_trainers];


                    for (int i = 0; i < num_trainers; i++) {
                      if (i == 0) all_maps[cur_y][cur_x]->npcs[i].type = char_hiker;
                      else if (i == 1 && num_trainers > 1) all_maps[cur_y][cur_x]->npcs[i].type = char_rival;
                      else all_maps[cur_y][cur_x]->npcs[i].type = (character_type_t) ((rand() % 7) + 1);

                      // maintain the turn queues
                      all_maps[cur_y][cur_x]->npcs[i].next_turn = pc.next_turn;
                      all_maps[cur_y][cur_x]->npcs[i].seq_num = i + 1;
                      all_maps[cur_y][cur_x]->npcs[i].x = -1;
                      all_maps[cur_y][cur_x]->npcs[i].y = -1;
                      all_maps[cur_y][cur_x]->npcs[i].defeated = 0;

                      generate_npc_trained_pokemon(&all_maps[cur_y][cur_x]->npcs[i], cur_x, cur_y);

                      place_entity(all_maps[cur_y][cur_x], &all_maps[cur_y][cur_x]->npcs[i], &pc, all_maps[cur_y][cur_x]->npcs, i);
                    }
                  }

                  // this happens wether or not the map is new
                  if (nx == 0) pc.x = MAP_X - 2;
                  if (nx == MAP_X - 1) pc.x = 1;
                  if (ny == 0) pc.y = MAP_Y - 2;
                  if (ny == MAP_Y - 1) pc.y = 1;

                  // must delete the old queue and load the new map characters in it ("want a turn queue per map")
                  heap_delete(&turn_queue);
                  heap_init(&turn_queue, character_turn_cmp, NULL);
                  for (int i = 0; i < all_maps[cur_y][cur_x]->num_trainers; i++) {
                    // set npc turns to player turns
                    if (all_maps[cur_y][cur_x]->npcs[i].next_turn < pc.next_turn) {
                      all_maps[cur_y][cur_x]->npcs[i].next_turn = pc.next_turn;
                    }
                    heap_insert(&turn_queue, &all_maps[cur_y][cur_x]->npcs[i]);
                  }

                  move_is_valid = 1;
                  break;
                }
                // mainly for flying, since gates should not be on the world border anyway
                else {
                  mvprintw(0, 0, "Can't go past world's border");
                  move_is_valid = 0;
                  continue;
                }
              }
              
              int npc_idx = get_occupied_npc_idx(&pc, cur_npcs, cur_num_trainers, nx, ny);
              
              if (npc_idx >= 0) {
                if(!cur_npcs[npc_idx].defeated) {

                  display_trainer_battle(&pc, &cur_npcs[npc_idx]);
                  cur_npcs[npc_idx].defeated = 1;

                  clear();
                  print_map_with_chars(all_maps[cur_y][cur_x], &pc, cur_npcs, cur_num_trainers);
                  move_is_valid = 1;
                }
                else {
                  mvprintw(0, 0, "this trainer is defeated");
                  // allow player to move over them (might want to change later! else have meatwalls of defeated trainers)
                  pc.x = nx;
                  pc.y = ny;
                  move_is_valid = 1;
                }
              }
              else {
                pc.x = nx;
                pc.y = ny;

                // if the player is now on a ter_grass, then they have a 10% chance to encounter a pokemon
                if (all_maps[cur_y][cur_x]->map[pc.y][pc.x] == ter_grass) {
                  if (rand() % 100 < 10) { 
                
                    // calculate level based on distance
                    int d = abs(cur_x - 200) + abs(cur_y - 200);
                    int min_level, max_level;

                    if (d <= 200) {
                      min_level = 1;
                      max_level = (d <= 1) ? 1 : d / 2;
                    } 
                    else {
                      min_level = (d - 200) / 2;
                      max_level = 100;
                    }
                  
                    // make sure levels are within 1 and 100
                    if (min_level < 1) min_level = 1;
                    if (max_level < 1) max_level = 1;
                    if (min_level > 100) min_level = 100;
                    if (max_level > 100) max_level = 100;

                    int level = (min_level == max_level) ? min_level : (rand() % (max_level - min_level + 1)) + min_level;

                    // generate and display the pokemon encounter
                    Pokemon wild_p(level);
                    display_pokemon_encounter(&wild_p, &pc);
                  }
                }
              }
              
          }
          else if (nx != pc.x || ny != pc.y) {
            mvprintw(0, 0, "can't move there");
            move_is_valid = 0;
          }
        }
      }
      if (game_is_quit) break;
      pc_position[0] = pc.x;
      pc_position[1] = pc.y;
      dijkstra_npc_dist(all_maps[cur_y][cur_x], pc_position, hiker_dist, char_hiker);
      dijkstra_npc_dist(all_maps[cur_y][cur_x], pc_position, rival_dist, char_rival);

      c->next_turn += get_terrain_cost(char_pc, all_maps[cur_y][cur_x]->map[c->y][c->x]);
    }
    else {
      move_npc(all_maps[cur_y][cur_x], c, &pc, cur_npcs, cur_num_trainers, hiker_dist, rival_dist);
      c->next_turn += get_terrain_cost(c->type, all_maps[cur_y][cur_x]->map[c->y][c->x]);
    }

    heap_insert(&turn_queue, c);
  }

  endwin();


  heap_delete(&turn_queue);
  for(int y = 0; y < 401; y++) {
    for(int x = 0; x < 401; x++) {
      if (all_maps[y][x]) {
        delete[] all_maps[y][x]->npcs;
        delete all_maps[y][x];
      }
    }
  }

  return 0;
}

