#ifndef DB_PARSING_H
#define DB_PARSING_H

#include <string>
#include <vector>
#include <fstream>
#include <iostream>

// classes for each of the csv files
// • pokemon.csv
// • moves.csv
// • pokemon moves.csv
// • pokemon species.csv
// • experience.csv
// • type names.csv
// • pokemon stats.csv
// • stats.csv
// • pokemon types.csv

// Your program should parse the specified file, print its contents to standard output (do not initialize curses),
// and exit. The whole game will still be compiled and linked, we’re simply exiting before running it.

// pokemon.csv
class pokemon {
    public:
    int id;
    std::string identifier;
    int species_id;
    int height;
    int weight;
    int base_experience;
    int order;
    int is_default;

    // constructor that takes a line of input as an argument
    pokemon(const std::string &line);

    // use const since read only
    void print() const;
};
void parse_pokemon(const std::string &filepath);

// moves.csv
class moves {
    public:
    int id;
    std::string identifier;
    int generation_id;
    int type_id;
    int power;
    int pp;
    int accuracy;
    int priority;
    int target_id;
    int damage_class_id;
    int effect_id;
    int effect_chance;
    int contest_type_id;
    int contest_effect_id;
    int super_contest_effect_id;
    
    moves(const std::string &line);
    void print() const;
};
void parse_moves(const std::string &filepath);

// pokemon moves.csv
class pokemon_moves {
    public:
    int pokemon_id;
    int version_group_id;
    int move_id;
    int pokemon_move_method_id;
    int level;
    int order;

    pokemon_moves(const std::string &line);
    void print() const;
};
void parse_pokemon_moves(const std::string &filepath);

// pokemon species.csv
class pokemon_species {
    public:
    int id;
    std::string identifier;
    int generation_id;
    int evolves_from_species_id;
    int evolution_chain_id;
    int color_id;
    int shape_id;
    int habitat_id;
    int gender_rate;
    int capture_rate;
    int base_happiness;
    int is_baby;
    int hatch_counter;
    int has_gender_differences;
    int growth_rate_id;
    int forms_switchable;
    int is_legendary;
    int is_mythical;
    int order;
    int conquest_order;

    pokemon_species(const std::string &line);
    void print() const;
};
void parse_pokemon_species(const std::string &filepath);

// experience.csv
class experience {
    public:
    int growth_rate_id;
    int level;
    int exp;

    experience(const std::string &line);
    void print() const;
};
void parse_experience(const std::string &filepath);

// type names.csv
class type_names {
    public:
    int type_id;
    int local_language_id;
    std:: string name;

    type_names(const std::string &line);
    void print() const;
};
void parse_type_names(const std::string &filepath);

// pokemon stats
class pokemon_stats {
    public:
    int pokemon_id;
    int stat_id;
    int base_stat;
    int effort;

    pokemon_stats(const std::string &line);
    void print() const;
};
void parse_pokemon_stats(const std::string &filepath);

// stats.csv
class stats {
    public:
    int id;
    int damage_class_id;
    std::string identifier;
    int is_battle_only;
    int game_index;

    stats(const std::string &line);
    void print() const;
};
void parse_stats(const std::string &filepath);

//pokemon types.csv
class pokemon_types {
    public:
    int pokemon_id;
    int type_id;
    int slot;

    pokemon_types(const std::string &line);
    void print() const;
};
void parse_pokemon_types(const std::string &filepath);




//template for parsing (cleans up db_passing.cpp a LOT)
template <typename T>
std::vector<T> parse_csv(const std::string &filepath, bool should_print = false) {
    std::ifstream file(filepath);
    std::vector<T> data_entries;


    if (!file.is_open()) {
        std::cout << "Data not found at " << filepath << std::endl;
        return data_entries;
    }

    std::string line;

    std::getline(file, line);
    //std::cout << line << std::endl; // comment out this line if want to remove the headers in parsed files later

    while (std::getline(file, line)) {
        // template deals with constructor, don't have to do data_entries.push_back(pokemon(line));
        // emplace_back constructs the element directly in place at end of vector (passes line to constructor)
        data_entries.emplace_back(line);
    }

    if (should_print) {
        for (const T &data_entry : data_entries) {
            data_entry.print();
        }
    }

    return data_entries;
}

// use extern to promise compiler that it exists and takes up memory in a differnet (external) file. (they are declared here)
extern std::vector<pokemon> pokemon_db;
extern std::vector<moves> moves_db;
extern std::vector<pokemon_moves> pokemon_moves_db;
extern std::vector<pokemon_species> pokemon_species_db;
extern std::vector<experience> experience_db;
extern std::vector<type_names> type_names_db;
extern std::vector<pokemon_stats> pokemon_stats_db;
extern std::vector<stats> stats_db;
extern std::vector<pokemon_types> pokemon_types_db;

#endif