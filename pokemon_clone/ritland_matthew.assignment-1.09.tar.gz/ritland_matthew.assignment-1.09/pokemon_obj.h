#ifndef POKEMON_OBJ_H
#define POKEMON_OBJ_H

#include "db_parsing.h"
#include <string>
#include <vector>

class Pokemon {
    public:
    const pokemon *base_species;
    int level;
    std::string gender;
    bool is_shiny;


    int hp, attack, defense, special_attack, special_defense, speed;
    int base_hp, base_attack, base_defense, base_special_attack, base_special_defense, base_speed;
    // IVs range from 0-15 (in binary 0000-1111)
    int iv_hp, iv_attack, iv_defense, iv_special_attack, iv_special_defense, iv_speed;

    int max_hp;
    // encountered pokemon know up to 2 moves
    const moves *move1;
    const moves *move2;

    // level will be passed other fields are randomized
    Pokemon(int level);

    void reduce_hp(int amount) {
        hp -= amount;
        if (hp < 0) hp = 0;
    }

    void print_stats() const;

    // getters
    int get_level() const { return level; }
    int get_hp() const { return hp; }
    int get_attack() const { return attack; }
    int get_defense() const { return defense; }
    int get_special_attack() const { return special_attack; }
    int get_special_defense() const { return special_defense; }
    int get_speed() const { return speed; }


    // if base_specieis exists, then return the identifier for it, otherwise return easy to see debug text 
    std::string get_species_identifier() const { 
        if (base_species) return base_species->identifier; 
        return "DID NOT FIND BASE SPECIES"; 
    }

    std::string get_move1_identifier() const { 
        if (move1) return move1->identifier; 
        return ""; 
    }

    std::string get_move2_identifier() const { 
        if (move2) return move2->identifier; 
        return ""; 
    }

    private:
    void get_base_stats();
    void calculate_stats();
    void select_moves();
};


#endif