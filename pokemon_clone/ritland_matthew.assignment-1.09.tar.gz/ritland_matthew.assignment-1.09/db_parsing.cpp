#include "db_parsing.h"
#include <iostream>
#include <climits>
#include <sstream>

// helper that checks if a string exists before converting a string to an int with stoi (don't use with non-numbers)
// if not, then return INT_MAX as placeholder
//carstoi = check and replace string to int
int car_stoi(const std::string &str) {
    if (str.empty()) return INT_MAX;
    return std::stoi(str);
}

// using pokemon constructor
pokemon::pokemon(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    // read the line s, go until first, store data into word
    std::getline(s, word, ',');
    // convert string word to int (only for data that is ints, DON'T DO FOR IDENTIFIER (string))
    id = car_stoi(word);

    std::getline(s, identifier, ',');

    std::getline(s, word, ',');
    species_id = car_stoi(word);

    std::getline(s, word, ',');
    height = car_stoi(word);

    std::getline(s, word, ',');
    weight = car_stoi(word);

    std::getline(s, word, ',');
    base_experience = car_stoi(word);

    std::getline(s, word, ',');
    order = car_stoi(word);

    std::getline(s, word, ',');
    is_default = car_stoi(word);
}

// std::cout << "output stuff" << std::endl
void pokemon::print() const {
    std::cout << (id ==INT_MAX ? "" : std::to_string(id)) << ","
        <<  identifier << ","
        << (species_id == INT_MAX ? "" : std::to_string(species_id)) << ","
        << (height == INT_MAX ? "" : std::to_string(height)) << ","
        << (weight == INT_MAX ? "" : std::to_string(weight)) << ","
        << (base_experience == INT_MAX ? "" : std::to_string(base_experience)) << ","
        << (order == INT_MAX ? "" : std::to_string(order)) << ","
        << (is_default == INT_MAX ? "" : std::to_string(is_default))
        << std::endl;
}





moves::moves(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    id = car_stoi(word);

    std::getline(s, identifier, ',');
    
    std::getline(s, word, ',');
    generation_id = car_stoi(word);

    std::getline(s, word, ',');
    type_id = car_stoi(word);

    std::getline(s, word, ',');
    power = car_stoi(word);

    std::getline(s, word, ',');
    pp = car_stoi(word);

    std::getline(s, word, ',');
    accuracy = car_stoi(word);

    std::getline(s, word, ',');
    priority = car_stoi(word);
    
    std::getline(s, word, ',');
    target_id = car_stoi(word);

    std::getline(s, word, ',');
    damage_class_id = car_stoi(word);

    std::getline(s, word, ',');
    effect_id = car_stoi(word);

    std::getline(s, word, ',');
    effect_chance = car_stoi(word);

    std::getline(s, word, ',');
    contest_type_id = car_stoi(word);

    std::getline(s, word, ',');
    contest_effect_id = car_stoi(word);

    std::getline(s, word, ',');
    super_contest_effect_id = car_stoi(word);
}


void moves::print() const {
    std::cout << (id ==INT_MAX ? "" : std::to_string(id)) << ","
        <<  identifier << ","
        << (generation_id == INT_MAX ? "" : std::to_string(generation_id)) << ","
        << (type_id == INT_MAX ? "" : std::to_string(type_id)) << ","
        << (power == INT_MAX ? "" : std::to_string(power)) << ","
        << (pp == INT_MAX ? "" : std::to_string(pp)) << ","
        << (accuracy == INT_MAX ? "" : std::to_string(accuracy)) << ","
        << (priority == INT_MAX ? "" : std::to_string(priority)) << ","
        << (target_id == INT_MAX ? "" : std::to_string(target_id)) << ","
        << (damage_class_id == INT_MAX ? "" : std::to_string(damage_class_id)) << ","
        << (effect_id == INT_MAX ? "" : std::to_string(effect_id)) << ","
        << (effect_chance == INT_MAX ? "" : std::to_string(effect_chance)) << ","
        << (contest_type_id == INT_MAX ? "" : std::to_string(contest_type_id)) << ","
        << (contest_effect_id == INT_MAX ? "" : std::to_string(contest_effect_id)) << ","
        << (super_contest_effect_id == INT_MAX ? "" : std::to_string(super_contest_effect_id))
        << std::endl;
}






pokemon_moves::pokemon_moves(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    pokemon_id = car_stoi(word);
    
    std::getline(s, word, ',');
    version_group_id = car_stoi(word);

    std::getline(s, word, ',');
    move_id = car_stoi(word);

    std::getline(s, word, ',');
    pokemon_move_method_id = car_stoi(word);

    std::getline(s, word, ',');
    level = car_stoi(word);

    std::getline(s, word, ',');
    order = car_stoi(word);
}

void pokemon_moves::print() const {
    std::cout << (pokemon_id == INT_MAX ? "" : std::to_string(pokemon_id)) << ","
        << (version_group_id == INT_MAX ? "" : std::to_string(version_group_id)) << ","
        << (move_id == INT_MAX ? "" : std::to_string(move_id)) << ","
        << (pokemon_move_method_id == INT_MAX ? "" : std::to_string(pokemon_move_method_id)) << ","
        << (level == INT_MAX ? "" : std::to_string(level)) << ","
        << (order == INT_MAX ? "" : std::to_string(order))
        << std::endl;
}






pokemon_species::pokemon_species(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    id = car_stoi(word);
    
    std::getline(s, identifier, ',');

    std::getline(s, word, ',');
    generation_id = car_stoi(word);

    std::getline(s, word, ',');
    evolves_from_species_id = car_stoi(word);

    std::getline(s, word, ',');
    evolution_chain_id = car_stoi(word);

    std::getline(s, word, ',');
    color_id = car_stoi(word);

    std::getline(s, word, ',');
    shape_id = car_stoi(word);

    std::getline(s, word, ',');
    habitat_id = car_stoi(word);
    
    std::getline(s, word, ',');
    gender_rate = car_stoi(word);

    std::getline(s, word, ',');
    capture_rate = car_stoi(word);

    std::getline(s, word, ',');
    base_happiness = car_stoi(word);

    std::getline(s, word, ',');
    is_baby = car_stoi(word);

    std::getline(s, word, ',');
    hatch_counter = car_stoi(word);

    std::getline(s, word, ',');
    has_gender_differences = car_stoi(word);

    std::getline(s, word, ',');
    growth_rate_id = car_stoi(word);

    std::getline(s, word, ',');
    forms_switchable = car_stoi(word);

    std::getline(s, word, ',');
    is_legendary = car_stoi(word);

    std::getline(s, word, ',');
    is_mythical = car_stoi(word);

    std::getline(s, word, ',');
    order = car_stoi(word);

    std::getline(s, word, ',');
    conquest_order = car_stoi(word);
}


void pokemon_species::print() const {
    std::cout << (id ==INT_MAX ? "" : std::to_string(id)) << ","
        <<  identifier << ","
        << (generation_id == INT_MAX ? "" : std::to_string(generation_id)) << ","
        << (evolves_from_species_id == INT_MAX ? "" : std::to_string(evolves_from_species_id)) << ","
        << (evolution_chain_id == INT_MAX ? "" : std::to_string(evolution_chain_id)) << ","
        << (color_id == INT_MAX ? "" : std::to_string(color_id)) << ","
        << (shape_id == INT_MAX ? "" : std::to_string(shape_id)) << ","
        << (habitat_id == INT_MAX ? "" : std::to_string(habitat_id)) << ","
        << (gender_rate == INT_MAX ? "" : std::to_string(gender_rate)) << ","
        << (capture_rate == INT_MAX ? "" : std::to_string(capture_rate)) << ","
        << (base_happiness == INT_MAX ? "" : std::to_string(base_happiness)) << ","
        << (is_baby == INT_MAX ? "" : std::to_string(is_baby)) << ","
        << (hatch_counter == INT_MAX ? "" : std::to_string(hatch_counter)) << ","
        << (has_gender_differences == INT_MAX ? "" : std::to_string(has_gender_differences)) << ","
        << (growth_rate_id == INT_MAX ? "" : std::to_string(growth_rate_id)) << ","
        << (forms_switchable == INT_MAX ? "" : std::to_string(forms_switchable)) << ","
        << (is_legendary == INT_MAX ? "" : std::to_string(is_legendary)) << ","
        << (is_mythical == INT_MAX ? "" : std::to_string(is_mythical)) << ","
        << (order == INT_MAX ? "" : std::to_string(order))  << ","
        << (conquest_order == INT_MAX ? "" : std::to_string(conquest_order))
        << std::endl;
}






experience::experience(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    growth_rate_id = car_stoi(word);
    
    std::getline(s, word, ',');
    level = car_stoi(word);

    std::getline(s, word, ',');
    exp = car_stoi(word);
}

void experience::print() const {
    std::cout << (growth_rate_id == INT_MAX ? "" : std::to_string(growth_rate_id)) << ","
        << (level == INT_MAX ? "" : std::to_string(level)) << ","
        << (exp == INT_MAX ? "" : std::to_string(exp))
        << std::endl;
}






type_names::type_names(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    type_id = car_stoi(word);
    
    std::getline(s, word, ',');
    local_language_id = car_stoi(word);

    std::getline(s, name, ',');
}

void type_names::print() const {
    std::cout << (type_id == INT_MAX ? "" : std::to_string(type_id)) << ","
        << (local_language_id == INT_MAX ? "" : std::to_string(local_language_id)) << ","
        <<  name
        << std::endl;
}





pokemon_stats::pokemon_stats(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    pokemon_id = car_stoi(word);
    
    std::getline(s, word, ',');
    stat_id = car_stoi(word);

    std::getline(s, word, ',');
    base_stat = car_stoi(word);

    std::getline(s, word, ',');
    effort = car_stoi(word);
}

void pokemon_stats::print() const {
    std::cout << (pokemon_id == INT_MAX ? "" : std::to_string(pokemon_id)) << ","
        << (stat_id == INT_MAX ? "" : std::to_string(stat_id)) << ","
        << (base_stat == INT_MAX ? "" : std::to_string(base_stat)) << ","
        << (effort == INT_MAX ? "" : std::to_string(effort))
        << std::endl;
}



stats::stats(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    id = car_stoi(word);
    
    std::getline(s, word, ',');
    damage_class_id = car_stoi(word);

    std::getline(s, identifier, ',');
    
    std::getline(s, word, ',');
    is_battle_only = car_stoi(word);

    std::getline(s, word, ',');
    game_index = car_stoi(word);
}

void stats::print() const {
    std::cout << (id ==INT_MAX ? "" : std::to_string(id)) << ","
        << (damage_class_id == INT_MAX ? "" : std::to_string(damage_class_id)) << ","
        <<  identifier << ","
        << (is_battle_only == INT_MAX ? "" : std::to_string(is_battle_only)) << ","
        << (game_index == INT_MAX ? "" : std::to_string(game_index))
        << std::endl;
}




pokemon_types::pokemon_types(const std::string &line) {
    std::stringstream s(line);
    std::string word;

    std::getline(s, word, ',');
    pokemon_id = car_stoi(word);
    
    std::getline(s, word, ',');
    type_id = car_stoi(word);
    
    std::getline(s, word, ',');
    slot = car_stoi(word);
}

void pokemon_types::print() const {
    std::cout << (pokemon_id == INT_MAX ? "" : std::to_string(pokemon_id)) << ","
        << (type_id == INT_MAX ? "" : std::to_string(type_id)) << ","
        << (slot == INT_MAX ? "" : std::to_string(slot))
        << std::endl;
}




