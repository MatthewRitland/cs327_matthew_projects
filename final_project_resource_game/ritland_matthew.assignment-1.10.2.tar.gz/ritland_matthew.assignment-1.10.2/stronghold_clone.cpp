#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <limits.h>
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>


#include <curses.h>

#include <cstdlib>
#include <vector>
#include <algorithm>
#include <chrono>
#include <cmath>

#define MAP_X 80
#define MAP_Y 21
#define MIN_TREES 10
#define MIN_BOULDERS 10
#define TREE_PROB 95
#define BOULDER_PROB 95


#define CHARACTER_START_WOOD 100
#define CHARACTER_START_STONE 50
#define CHARACTER_START_GOLD 1
#define DEFAULT_GOLD_WIN_TARGET 300

#define WOODCUTTER_COST_WOOD 0
#define WOODCUTTER_COST_STONE 10
#define STONECUTTER_COST_WOOD 20
#define STONECUTTER_COST_STONE 0
#define GOLDCUTTER_COST_WOOD 30
#define GOLDCUTTER_COST_STONE 10

#define WOODCUTTER_YIELD 3
#define STONECUTTER_YIELD 2
#define GOLDCUTTER_YIELD 1

#define REFRESH_VALUE 1000


typedef enum __attribute__ ((__packed__)) terrain_type {
  ter_debug,
  ter_boulder,
  ter_tree,
  ter_path,
  ter_grass,
  ter_clearing,
  ter_mountain,
  ter_forest,
  ter_water
} terrain_type_t;

typedef struct queue_node {
  int x, y;
  struct queue_node *next;
} queue_node_t;

class map_t {
public:
  terrain_type_t map[MAP_Y][MAP_X];
  uint8_t height[MAP_Y][MAP_X];
};

class character_t {
public:
  int x, y;
  int wood = CHARACTER_START_WOOD; 
  int stone = CHARACTER_START_STONE;
  int gold = CHARACTER_START_GOLD;
};

enum BuildingType {
    TYPE_WOODCUTTER,
    TYPE_STONECUTTER,
    TYPE_GOLDCUTTER
};

class Building {
public:
  BuildingType type;
  int x, y;
  char symbol;
  int color_pair;
  int wood_yield;
  int stone_yield;
  int gold_yield;

  Building(BuildingType t, int start_x, int start_y, char sym, int color, int wood_rate, int stone_rate, int gold_rate) {
    type = t;
    x = start_x;
    y = start_y;
    symbol = sym;
    color_pair = color;
    wood_yield = wood_rate;
    stone_yield = stone_rate;
    gold_yield = gold_rate;
  }
};

struct BuildingCost {
    int wood;
    int stone;
};

struct BuildingYield {
    int wood;
    int stone;
    int gold;
};

int enemy_gold;

std::vector<Building> placed_buildings;


static int gaussian[5][5] = {
  {  1,  4,  7,  4,  1 },
  {  4, 16, 26, 16,  4 },
  {  7, 26, 41, 26,  7 },
  {  4, 16, 26, 16,  4 },
  {  1,  4,  7,  4,  1 }
};
static int smooth_height(map_t *m)
{
  int32_t i, x, y;
  int32_t s, t, p, q;
  queue_node_t *head, *tail, *tmp;
  /*  FILE *out;*/
  uint8_t height[MAP_Y][MAP_X];

  memset(&height, 0, sizeof (height));

  /* Seed with some values */
  for (i = 1; i < 255; i += 20) {
    do {
      x = rand() % MAP_X;
      y = rand() % MAP_Y;
    } while (height[y][x]);
    height[y][x] = i;
    if (i == 1) {
      head = tail = new queue_node_t();
    } else {
      tail->next = new queue_node_t();
      tail = tail->next;
    }
    tail->next = NULL;
    tail->x = x;
    tail->y = y;
  }

  /*
  out = fopen("seeded.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&height, sizeof (height), 1, out);
  fclose(out);
  */
  
  /* Diffuse the vaules to fill the space */
  while (head) {
    x = head->x;
    y = head->y;
    i = height[y][x];

    if (x - 1 >= 0 && y - 1 >= 0 && !height[y - 1][x - 1]) {
      height[y - 1][x - 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y - 1;
    }
    if (x - 1 >= 0 && !height[y][x - 1]) {
      height[y][x - 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y;
    }
    if (x - 1 >= 0 && y + 1 < MAP_Y && !height[y + 1][x - 1]) {
      height[y + 1][x - 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y + 1;
    }
    if (y - 1 >= 0 && !height[y - 1][x]) {
      height[y - 1][x] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x;
      tail->y = y - 1;
    }
    if (y + 1 < MAP_Y && !height[y + 1][x]) {
      height[y + 1][x] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x;
      tail->y = y + 1;
    }
    if (x + 1 < MAP_X && y - 1 >= 0 && !height[y - 1][x + 1]) {
      height[y - 1][x + 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y - 1;
    }
    if (x + 1 < MAP_X && !height[y][x + 1]) {
      height[y][x + 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y;
    }
    if (x + 1 < MAP_X && y + 1 < MAP_Y && !height[y + 1][x + 1]) {
      height[y + 1][x + 1] = i;
      tail->next = new queue_node_t();
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y + 1;
    }

    tmp = head;
    head = head->next;
    delete tmp;
  }

  /* And smooth it a bit with a gaussian convolution */
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      for (s = t = p = 0; p < 5; p++) {
        for (q = 0; q < 5; q++) {
          if (y + (p - 2) >= 0 && y + (p - 2) < MAP_Y &&
              x + (q - 2) >= 0 && x + (q - 2) < MAP_X) {
            s += gaussian[p][q];
            t += height[y + (p - 2)][x + (q - 2)] * gaussian[p][q];
          }
        }
      }
      m->height[y][x] = t / s;
    }
  }
  /* Let's do it again, until it's smooth like Kenny G. */
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      for (s = t = p = 0; p < 5; p++) {
        for (q = 0; q < 5; q++) {
          if (y + (p - 2) >= 0 && y + (p - 2) < MAP_Y &&
              x + (q - 2) >= 0 && x + (q - 2) < MAP_X) {
            s += gaussian[p][q];
            t += height[y + (p - 2)][x + (q - 2)] * gaussian[p][q];
          }
        }
      }
      m->height[y][x] = t / s;
    }
  }

  /*
  out = fopen("diffused.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&height, sizeof (height), 1, out);
  fclose(out);

  out = fopen("smoothed.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->height, sizeof (m->height), 1, out);
  fclose(out);
  */

  return 0;
}

static terrain_type_t border_type(map_t *m, int32_t x, int32_t y)
{
  int32_t p, q;
  int32_t r, t;
  int32_t miny, minx, maxy, maxx;
  
  r = t = 0;
  
  miny = y - 1 >= 0 ? y - 1 : 0;
  maxy = y + 1 <= MAP_Y ? y + 1: MAP_Y;
  minx = x - 1 >= 0 ? x - 1 : 0;
  maxx = x + 1 <= MAP_X ? x + 1: MAP_X;

  for (q = miny; q < maxy; q++) {
    for (p = minx; p < maxx; p++) {
      if (q != y || p != x) {
        if (m->map[q][p] == ter_mountain ||
            m->map[q][p] == ter_boulder) {
          r++;
        } else if (m->map[q][p] == ter_forest ||
                   m->map[q][p] == ter_tree) {
          t++;
        }
      }
    }
  }
  
  if (t == r) {
    return rand() & 1 ? ter_boulder : ter_tree;
  } else if (t > r) {
    if (rand() % 10) {
      return ter_tree;
    } else {
      return ter_boulder;
    }
  } else {
    if (rand() % 10) {
      return ter_boulder;
    } else {
      return ter_tree;
    }
  }
}

static int map_terrain(map_t *m)
{
  int32_t i, x, y;
  queue_node_t *head, *tail, *tmp;
  //  FILE *out;
  int num_grass, num_clearing, num_mountain, num_forest, num_water, num_total;
  terrain_type_t type;
  int added_current = 0;
  
  num_grass = rand() % 4 + 2;
  num_clearing = rand() % 4 + 2;
  num_mountain = rand() % 2 + 1;
  num_forest = rand() % 2 + 1;
  num_water = rand() % 2 + 1;
  num_total = num_grass + num_clearing + num_mountain + num_forest + num_water;

  memset(&m->map, 0, sizeof (m->map));

  /* Seed with some values */
  for (i = 0; i < num_total; i++) {
    do {
      x = rand() % MAP_X;
      y = rand() % MAP_Y;
    } while (m->map[y][x]);
    if (i == 0) {
      type = ter_grass;
    } else if (i == num_grass) {
      type = ter_clearing;
    } else if (i == num_grass + num_clearing) {
      type = ter_mountain;
    } else if (i == num_grass + num_clearing + num_mountain) {
      type = ter_forest;
    } else if (i == num_grass + num_clearing + num_mountain + num_forest) {
      type = ter_water;
    }
    m->map[y][x] = type;
    if (i == 0) {
      head = tail = new queue_node_t();
    } else {
      tail->next = new queue_node_t();
      tail = tail->next;
    }
    tail->next = NULL;
    tail->x = x;
    tail->y = y;
  }

  /*
  out = fopen("seeded.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->map, sizeof (m->map), 1, out);
  fclose(out);
  */
  
  /* Diffuse the vaules to fill the space */
  while (head) {
    x = head->x;
    y = head->y;
    i = m->map[y][x];
    
    if (x - 1 >= 0 && !m->map[y][x - 1]) {
      if ((rand() % 100) < 80) {
        m->map[y][x - 1] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x - 1;
        tail->y = y;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (y - 1 >= 0 && !m->map[y - 1][x]) {
      if ((rand() % 100) < 20) {
        m->map[y - 1][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y - 1;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (y + 1 < MAP_Y && !m->map[y + 1][x]) {
      if ((rand() % 100) < 20) {
        m->map[y + 1][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y + 1;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (x + 1 < MAP_X && !m->map[y][x + 1]) {
      if ((rand() % 100) < 80) {
        m->map[y][x + 1] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x + 1;
        tail->y = y;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = (terrain_type_t) i;
        tail->next = new queue_node_t();
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    added_current = 0;
    tmp = head;
    head = head->next;
    delete tmp;
  }

  /*
  out = fopen("diffused.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->map, sizeof (m->map), 1, out);
  fclose(out);
  */
  
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      if (y == 0 || y == MAP_Y - 1 ||
          x == 0 || x == MAP_X - 1) {
            m->map[y][x] = type = border_type(m, x, y);
      }
    }
  }

  return 0;
}

static int place_boulders(map_t *m)
{
  int i;
  int x, y;

  for (i = 0; i < MIN_BOULDERS || rand() % 100 < BOULDER_PROB; i++) {
    y = rand() % (MAP_Y - 2) + 1;
    x = rand() % (MAP_X - 2) + 1;
    if (m->map[y][x] != ter_forest && m->map[y][x] != ter_path) {
      m->map[y][x] = ter_boulder;
    }
  }

  return 0;
}

static int place_trees(map_t *m)
{
  int i;
  int x, y;
  
  for (i = 0; i < MIN_TREES || rand() % 100 < TREE_PROB; i++) {
    y = rand() % (MAP_Y - 2) + 1;
    x = rand() % (MAP_X - 2) + 1;
    if (m->map[y][x] != ter_mountain &&
        m->map[y][x] != ter_path     &&
        m->map[y][x] != ter_water) {
      m->map[y][x] = ter_tree;
    }
  }

  return 0;
}

static int new_map(map_t *m)
{
  smooth_height(m);
  map_terrain(m);
  place_boulders(m);
  place_trees(m);
  return 0;
}

static void print_map_with_chars(map_t *m, character_t *pc)
{
  int x, y;
  int y_print_offset = 3;
  int x_print_offset = 2;
  
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {

      if (pc->x == x && pc->y == y) {
        attron(COLOR_PAIR(8));
        mvaddch(y + y_print_offset, x + x_print_offset, '@');
        attroff(COLOR_PAIR(8));
        continue;
      }

      bool is_building = false;
      for (size_t i = 0; i < placed_buildings.size(); i++) {
        if (placed_buildings[i].x == x && placed_buildings[i].y == y) {
            attron(COLOR_PAIR(placed_buildings[i].color_pair));
            mvaddch(y + y_print_offset, x + x_print_offset, placed_buildings[i].symbol);
            attroff(COLOR_PAIR(placed_buildings[i].color_pair));
            is_building = true;
            break;
        }
      }

      if (is_building) continue;

      char ter_char;
      int color = 0;

      switch (m->map[y][x]) {
        case ter_boulder:
        case ter_mountain:
            ter_char = '%';
            color = 4;
            break;
        case ter_tree:
        case ter_forest:
            ter_char = '^';
            color = 2;
            break;
        case ter_grass:
            ter_char = ':';
            color = 1;
            break;
        case ter_clearing:
            ter_char = '.';
            color = 1;
            break;
        case ter_water:
            ter_char = '~';
            color = 3;
            break;
        default: break;
      }
      if(y == 0 || y == MAP_Y - 1 || x == 0 || x == MAP_X - 1) {
        color = 7; // set any chars on the border to be yellow
      }

      if (color) attron(COLOR_PAIR(color));
      mvaddch(y + y_print_offset, x + x_print_offset, ter_char);
      if (color) attroff(COLOR_PAIR(color));
    }
  }
  // goes to terminal screen
  refresh();
}

// helper to check if a tile is occupied (for just buildings)
bool tile_is_occupied(int x_check, int y_check) {
    for (size_t i = 0; i < placed_buildings.size(); i++) {
        if (placed_buildings[i].x == x_check && placed_buildings[i].y == y_check) {
            return true; 
        }
    }
    return false;
}

// buildings should get more and more expensive as the player keeps placing them
BuildingCost calculate_building_cost(BuildingType type) {
    int count = 0;
    for (size_t i = 0; i < placed_buildings.size(); i++) {
        if (placed_buildings[i].type == type) {
            count++;
        }
    }

    float multiplyer = std::pow(1.2f, count); // 1.2^n, where n is number of buildings
    BuildingCost cost;
    if (type == TYPE_WOODCUTTER) {
        cost.wood = (int)(WOODCUTTER_COST_WOOD*multiplyer);
        cost.stone = (int)(WOODCUTTER_COST_STONE*multiplyer);
    }
    else if (type == TYPE_STONECUTTER) {
        cost.wood = (int)(STONECUTTER_COST_WOOD*multiplyer);
        cost.stone = STONECUTTER_COST_STONE*multiplyer;
    }
    else if (type == TYPE_GOLDCUTTER) {
        cost.wood = (int)(GOLDCUTTER_COST_WOOD*multiplyer);
        cost.stone = (int)(GOLDCUTTER_COST_STONE*multiplyer);
    }
    return cost;
}

BuildingYield get_building_yield(BuildingType type) {
    BuildingYield yield;
    yield.wood = 0;
    yield.stone = 0;
    yield.gold = 0;
    
    if(type == TYPE_WOODCUTTER) {
        yield.wood = WOODCUTTER_YIELD;
    }
    else if (type == TYPE_STONECUTTER) {
        yield.stone = STONECUTTER_YIELD;
    }
    else if (type == TYPE_GOLDCUTTER) {
        yield.gold = GOLDCUTTER_YIELD;
    }
    return yield;
}

// this is how the player places things
void build_menu(character_t* pc, map_t* map) {
    if (tile_is_occupied(pc->x, pc->y)) {
        mvprintw(0, 0, "                                                ");
        mvprintw(0, 0, "Can't place a building here!");
        timeout(REFRESH_VALUE);
        getch();
        return;
    }
    bool in_menu = true;

    while (in_menu) {
        clear();

        BuildingCost woodcutter_cost = calculate_building_cost(TYPE_WOODCUTTER);
        BuildingCost stonecutter_cost = calculate_building_cost(TYPE_STONECUTTER);
        BuildingCost goldcutter_cost = calculate_building_cost(TYPE_GOLDCUTTER);

        BuildingYield woodcutter_yield = get_building_yield(TYPE_WOODCUTTER);
        BuildingYield stonecutter_yield = get_building_yield(TYPE_STONECUTTER);
        BuildingYield goldcutter_yield = get_building_yield(TYPE_GOLDCUTTER);


        mvprintw(2, 2, "BUILD MENU");
        mvprintw(3, 2, "Available Resources: %d Wood | %d Stone", pc->wood, pc->stone);
        mvprintw(5, 2, "1: Woodcutter [%d Wood, %d Stone] +%d Wood Production", woodcutter_cost.wood, woodcutter_cost.stone, woodcutter_yield.wood);
        mvprintw(6, 2, "2: Stonecutter [%d Wood] +%d Stone Production", stonecutter_cost.wood, stonecutter_yield.stone);
        mvprintw(7, 2, "3: GoldCutter [%d Wood, %d Stone] +%d Gold Production", goldcutter_cost.wood, goldcutter_cost.stone, goldcutter_yield.gold);
        mvprintw(9, 2, "ESC: Cancel");
        refresh();

        int choice = getch();

        // store which terrain type the user is on, since cutters can only go on reasonable terrains
        terrain_type_t current_terrain = map->map[pc->y][pc->x];

        // if they press ESC, go out of menue
        if (choice == 27) {
            in_menu = false;
        } 
        else if (choice == '1') {
            if (current_terrain != ter_tree && current_terrain != ter_forest) {
                mvprintw(10, 2, "Woodcutters must be placed on a tree!  '^'");
                timeout(REFRESH_VALUE);
                getch();
            }
            else if (pc->wood >= woodcutter_cost.wood && pc->stone >= woodcutter_cost.stone) {
                pc->wood -= woodcutter_cost.wood;
                pc->wood -= woodcutter_cost.stone;
                placed_buildings.push_back(Building(TYPE_WOODCUTTER, pc->x, pc->y, 'W', 5, woodcutter_yield.wood, woodcutter_yield.stone, woodcutter_yield.gold));
                mvprintw(10, 2, "WoodCutter Placed!");
                timeout(REFRESH_VALUE);
                getch();
                in_menu = false;
            }
            else {
                mvprintw(10, 2, "Not Enough Resources!!");
                timeout(REFRESH_VALUE);
                getch();
            }
        }
        else if (choice == '2') {
            if (current_terrain != ter_boulder) {
                mvprintw(10, 2, "Stonecutters must be placed on a boulder!  '%%'");
                timeout(REFRESH_VALUE);
                getch();
            }
            else if (pc->wood >= stonecutter_cost.wood) {
                pc->wood -= stonecutter_cost.wood;
                placed_buildings.push_back(Building(TYPE_STONECUTTER, pc->x, pc->y, 'S', 5, stonecutter_yield.wood, stonecutter_yield.stone, stonecutter_yield.gold));
                mvprintw(10, 2, "StoneCutter Placed!");
                timeout(REFRESH_VALUE);
                getch();
                in_menu = false;
            }
            else {
                mvprintw(10, 2, "Not Enough Resources!!");
                timeout(REFRESH_VALUE);
                getch();
            }
        }
        else if (choice == '3') {
            if (current_terrain != ter_clearing && current_terrain != ter_grass) {
                mvprintw(10, 2, "Goldcutters must be placed on grass!  '.' or ':'");
                timeout(REFRESH_VALUE);
                getch();
            }
            else if (pc->wood >= goldcutter_cost.wood && pc->stone >= goldcutter_cost.stone) {
                pc->wood -= goldcutter_cost.wood;
                pc->stone -= goldcutter_cost.stone;
                
                // use push_back() to add the new element to the end of the vector 
                // (don't use emplace_back since not constructing an object directly in the vector's memeory)
                placed_buildings.push_back(Building(TYPE_GOLDCUTTER, pc->x, pc->y, 'G', 5, goldcutter_yield.wood, goldcutter_yield.stone, goldcutter_yield.gold));
                mvprintw(10, 2, "GoldCutter Placed!");
                timeout(REFRESH_VALUE);
                getch();
                in_menu = false;
            }
            else {
                mvprintw(10, 2, "Not Enough Resources!!");
                timeout(REFRESH_VALUE);
                getch();
            }
        }
    }
    clear();
}


int display_info_screen() {
  clear();
  mvprintw(0, 2, "------------------------------------------ INFORMATION ON HOW TO PLAY ------------------------------------------");
  mvprintw(2, 2, "WECOME! While in game, 'Q' to quit.");


  mvprintw(5, 4, "HOW DO I EXPAND MY VILLAGE?");
  mvprintw(6, 6,   "- Build resource generating buildings by pressing 'B' to open the building menu (after this screen)");
  mvprintw(7, 6,   "- You must have sufficient resources to do so! Also, it matters where you try to place buildings.");
  mvprintw(8, 6,   "- By selecting a building, you attempt to PLACE that building BENEATH your character!");
  
  mvprintw(10, 4, "WHAT RESOURCES ARE THERE?");
  mvprintw(11, 6,   "- There are 3 types of resources, Wood, Stone, and Gold");
  mvprintw(12, 8,     "- Wood and Stone are used for building. By default, reaching 300 gold before the bot means you win.");
  mvprintw(13, 10,       "- NOTE: you may change the target amount of gold in this screen, or by running './stronghold_clone' <gold target>");

  mvprintw(15, 4, "HOW DO I GET THESE RESOURCES?");
  mvprintw(16, 6,   "- There are 3 types of buildings, WoodCutter, StoneCutter, and GoldCutter. These buidings generate their resource.");
  mvprintw(17, 8,     "- StoneCutter must be placed on Boulders '%%' (larger groups of '%%' are mountains, which are unpassable)");
  mvprintw(18, 8,     "- WoodCutter must be placed on Trees '^'");
  mvprintw(19, 8,     "- GoldCutter must be placed on Grass '.' or ':'");

  mvprintw(21, 4, "OBJECTIVE");
  mvprintw(22, 6, "- Reach the target gold amount before the bot does! Be mindful that buildings get more expensive for each building placed.");
  mvprintw(23, 6, "- You must defend your village from attacks! You wil lose if the attacker steals enough");

  mvprintw(25, 4, "DESIRED GOLD TARGET: ('enter' for default 300, 0 for endless mode): ");

  refresh();

  char input[20];
  int valid_input = 0;
  int gold_target = 300;

  echo();
  curs_set(1);

  while(!valid_input) {
    getnstr(input, 16);
    if(strlen(input) == 0) {
      valid_input = 1;
      break;
    }
    valid_input = 1;

    for(int i = 0; input[i] != '\0'; i ++) {
      if (!isdigit(input[i])) {
        valid_input = 0;
        break;
      }
    }
    
    if(valid_input) {
      gold_target = atoi(input);
    }
    else {
      attron(COLOR_PAIR(5));
      mvprintw(26, 4, "Invalid input! Enter numbers only!");
      attroff(COLOR_PAIR(5));
      move(25, 72);
      clrtoeol();
    }
  }
  noecho();
  curs_set(0);
  return gold_target;
}



// ---------------------- STEALING STUFF START ----------------------
int stealing_skill_check() {
  int bar_length = 40;
  int target_len = 4;
  int target_start = (bar_length/4) + (rand() % ((bar_length - target_len) - bar_length/4 + 1));
  int cursor_pos = 0;
  int defended = 0;

  timeout(0);

  clear();
  flushinp();
  attron(COLOR_PAIR(7));
  mvprintw(MAP_Y/2 -2, MAP_X/2 - 27, "         ------ YOU ARE BEING ATTACKED ------");
  attroff(COLOR_PAIR(7));
  mvprintw(MAP_Y/2 -1, MAP_X/2 -27, "------ Press SPACE in the GREEN zone to defend! ------");
  

  move(MAP_Y/2, MAP_X/2 - bar_length/2 -1);
  printw("[");
  for(int i = 0; i < bar_length; i++) {
    if(i >= target_start && i < target_start + target_len) {
      attron(COLOR_PAIR(1));
      printw("=");
      attroff(COLOR_PAIR(1));
    }
    else {
      printw("-");
    }
  }
  
  printw("]");

  refresh();
  napms(1000);
  flushinp();
  while(1) {
    move(MAP_Y/2, MAP_X/2 - bar_length/2 -1);
    
    mvprintw(MAP_Y/2+1, MAP_X/2 - bar_length/2 + 1 + cursor_pos - 1, "^");
    refresh();
    napms(50);

    int pressed;
    pressed = getch();
    if (pressed == ' ') {
      if (cursor_pos >= target_start && cursor_pos < target_start + target_len) {
        defended = 1;
      }
      else {
        defended = 0;
      }
      break;
    }
    mvprintw(MAP_Y/2+1, MAP_X/2 - bar_length/2 + 1 + cursor_pos - 1, "-");
    cursor_pos++;

    if (cursor_pos >= bar_length) {
      defended = 0;
      break;
    }
  }
  clear();
  
  if (defended) {
    attron(COLOR_PAIR(1));
    mvprintw(MAP_Y/2, MAP_X/2 - 14, "------ NICE DEFENSE! ------");
    attroff(COLOR_PAIR(1));
  }
  else {
    attron(COLOR_PAIR(7));
    mvprintw(MAP_Y/2, MAP_X/2 - 20, "------ OH NO! THEY TOOK SOME GOLD! ------");
    attroff(COLOR_PAIR(7));
  }
  refresh();
  napms(2000);
  flushinp();
  timeout(REFRESH_VALUE);
  return defended;
}
// ----------------------- STEALING STUFF END ----------------------


int main(int argc, char *argv[]) {
  int gold_win_target = DEFAULT_GOLD_WIN_TARGET; // -1 input will be endless from info screen will be endless 
                                                 // (but can also enter as arg, and skip info screen)

  if(argc > 1) {
    gold_win_target = atoi(argv[1]);
  }

  struct timeval tv;
  uint32_t seed;
  gettimeofday(&tv, NULL);
  seed = (tv.tv_usec ^ (tv.tv_sec << 20)) & 0xffffffff;
  printf("Using seed: %u\n", seed);
  srand(seed);

  // ncurses stuff
  initscr();
  start_color();
  curs_set(0);

  // color pairs (id, fg color, bg color)
  init_pair(1, COLOR_GREEN, COLOR_BLACK); // tall grass/clearings,
  init_pair(2, COLOR_WHITE, COLOR_BLACK); // trees // ncurses only has 8 colors, so brown didn't work. might change trees only later
  init_pair(3, COLOR_BLUE, COLOR_BLACK); // water
  init_pair(4, COLOR_WHITE, COLOR_BLACK); // boulders/mountains
  init_pair(5, COLOR_YELLOW, COLOR_BLACK); // paths/gates
  init_pair(6, COLOR_CYAN, COLOR_BLACK); // OPEN FOR SOMETHING ELSE
  init_pair(7, COLOR_RED, COLOR_BLACK); // OPEN FOR SOMETHING ELSE
  init_pair(8, COLOR_MAGENTA, COLOR_BLACK); // PC
  init_pair(9, COLOR_WHITE, COLOR_BLACK);

  bkgd(COLOR_PAIR(9));

  noecho();
  raw(); // makes input unbuffered (don't need to press enter)
  keypad(stdscr, TRUE); // enable use of arrow keys
  // if target was given in argv, then skip this
  if (!(argc > 1)) gold_win_target = display_info_screen();
  clear();

  timeout(REFRESH_VALUE); // need this so game still runs even if no input

  map_t* village_map = new map_t();
  new_map(village_map);

  // initialize pc
  character_t pc;
  pc.x = MAP_X/2;
  pc.y = MAP_Y/2;
  while (village_map->map[pc.y][pc.x] == ter_mountain || village_map->map[pc.y][pc.x] == ter_water) {
    pc.x = (rand() % (MAP_X-2)) + 1;
    pc.y = (rand() % (MAP_Y-2)) + 1;

  }

  int previous_gold = pc.gold;
  int game_is_quit = 0;
  enemy_gold = 0;

  int triggered_at_20 = 0;
  int triggered_at_40 = 0;
  int triggered_at_60 = 0;
  
  auto start = std::chrono::steady_clock::now(); // this implementation pattern of clock is mainly found from google (from cpp <chrono>)

  while(!game_is_quit) {
      print_map_with_chars(village_map, &pc);
      attron(COLOR_PAIR(5));
      mvprintw(0, 2, "VILLAGE | Wood: %d | Stone: %d   (press 'B' to build...)", pc.wood, pc.stone);
      mvprintw(1, 2, "PLAYER  | Gold: %d/%d  (press 'B' to build...)", pc.gold, gold_win_target);
      attroff(COLOR_PAIR(5));
      attron(COLOR_PAIR(8));
      mvprintw(2, 2, "ENEMY | Gold: %d/%d", enemy_gold, gold_win_target);
      attroff(COLOR_PAIR(8));
      refresh();

      int key = getch();
      int nx = pc.x;
      int ny = pc.y;

      switch(key) {
          case '7': case 'y': nx--; ny--; break;
          case '8': case 'k': case 'w': ny--; break; 
          case '9': case 'u': nx++; ny--; break;
          case '6': case 'l': case 'd': nx++; break;
          case '3': case 'n': nx++; ny++; break;
          case '2': case 'j': case 's': ny++; break;
          case '1': case 'b': nx--; ny++; break;
          case '4': case 'h': case 'a': nx--; break;
          case 'Q': game_is_quit = 1; break;
          case 'B': build_menu(&pc, village_map); break;
      }
      // check if player can move that way (only can't walk on water/boulder)
      if (nx > 0 && nx < MAP_X - 1 && ny > 0 && ny < MAP_Y - 1) {
          terrain_type_t ter_type = village_map->map[ny][nx];
          if (/*ter_type != ter_boulder && */ter_type != ter_mountain && ter_type != ter_water) {
              pc.x = nx;
              pc.y = ny;
          }
      }

      auto end = std::chrono::steady_clock::now();
      auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

      if (duration >= 100) {
          for (size_t i = 0; i < placed_buildings.size(); i++) {
            pc.wood += placed_buildings[i].wood_yield;
            pc.stone += placed_buildings[i].stone_yield;
            pc.gold += placed_buildings[i].gold_yield;
          }

          start = end; // refresh the clock start time
      }

      float current_percent = (float)pc.gold/gold_win_target;
      float previous_percent = (float)previous_gold/gold_win_target;

      int steal_triggered = 0;
      if (previous_percent < 0.2f && current_percent >= 0.2f && !triggered_at_20) {
        steal_triggered = 1;
        triggered_at_20 = 1;
      }
      else if (previous_percent < 0.4f && current_percent >= 0.4f && !triggered_at_40) {
        steal_triggered = 1;
        triggered_at_40 = 1;
      }
      else if (previous_percent < 0.6f && current_percent >= 0.6f && !triggered_at_60) {
        steal_triggered = 1;
        triggered_at_60 = 1;
      }
      else {
        if (pc.gold > previous_gold) {
          // every time gold is generated, there is a 2% chance, up to 10% chance (if player almost at goal) for there to be another steal
          int steal_chance = 1 + (int)(current_percent * 8.0f);
          if ((rand() % 100) < steal_chance) {
            steal_triggered = 1;
          }
        }
      }

      if (steal_triggered) {
        int stolen = stealing_skill_check();
        if (!stolen) {
          enemy_gold += pc.gold/2;
          pc.gold = pc.gold/2;
        }
      }
      if (pc.gold >= gold_win_target && gold_win_target > 0) {
          clear();
          mvprintw(MAP_Y / 2, (MAP_X / 2), "YOU WIN!!!");
          mvprintw((MAP_Y / 2) +1, (MAP_X / 2), "Game will now close...");
          refresh();
          napms(3000);
          getch();
          game_is_quit = 1;
      }
      else if (enemy_gold >= gold_win_target && gold_win_target > 0) {
        clear();
        mvprintw(MAP_Y / 2, (MAP_X / 2), "YOU LOOOOOOSE!!!");
        mvprintw((MAP_Y / 2) +1, (MAP_X / 2), "Game will now close...");
        refresh();
        napms(3000);
        getch();
        game_is_quit = 1;
      }
  }


  endwin();
  delete village_map;
  return 0;
}